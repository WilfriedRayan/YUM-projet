<?php
include __DIR__."/configs.php";

// Assurez-vous que cette page est appelée via une requête POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données JSON envoyées dans le corps de la requête
    $data = json_decode(file_get_contents('php://input'), true);

    // Vérifier si les données nécessaires sont présentes
    if (isset($data['driverId'], $data['orderId'])) {
        // Récupérer l'ID du livreur et l'ID de la commande
        $driverId = $data['driverId'];
        $orderId = $data['orderId'];

        // Vérifier si les IDs sont valides
        if ($orderId && $driverId) {

            // Insérer une notification pour le conducteur
        $message = "A new order has been assigned to you.";
        $sql1 = "INSERT INTO pl_notifications (message, driver_id) VALUES (?, ?)";
        $stmt1 = $db->prepare($sql1);
        $stmt1->bind_param('si', $message, $driverId);
        $stmt1->execute();

            try {
                // Préparer la requête SQL pour mettre à jour la commande avec l'ID du livreur
                $sql = "UPDATE pl_orders SET driver_id = ? WHERE id = ?";
                $stmt = $db->prepare($sql);
                // Exécuter la requête en liant les valeurs aux paramètres
                $stmt->execute([$driverId, $orderId]);

                // Vérifier si la mise à jour a réussi
                if ($stmt->rowCount() > 0) {
                    // La mise à jour a réussi
                    $alert = ["alert" => $lang['alerts']['alldone'], "type" => "success"];
                    echo json_encode(['success' => 'Driver assigned successfully']);
                    echo json_encode($alert);

                    // Vérifier si l'insertion de la notification a réussi
                    if ($stmt1->affected_rows > 0) {
                        // L'insertion de la notification a réussi
                        echo json_encode(['notification' => 'Notification inserted successfully']);
                    } else {
                        // L'insertion de la notification a échoué
                        echo json_encode(['notification_error' => 'Failed to insert notification']);
                    }
                } else {
                    // La mise à jour a échoué
                    echo json_encode(['error' => 'Failed to assign driver']);
                }
                

            } catch (PDOException $e) {
                // Gérer les erreurs liées à la base de données
                echo json_encode(['error' => 'Database error: '.$e->getMessage()]);
            }
        } else {
            // ID de commande ou de conducteur manquant
            echo json_encode(['error' => 'Order ID or driver ID missing']);
        }

    } else {
        // Envoyer une réponse JSON indiquant que les données sont manquantes
        echo json_encode(['error' => 'Driver ID or Order ID missing']);
    }
} else {
    // Envoyer une réponse JSON indiquant que la méthode de requête n'est pas prise en charge
    echo json_encode(['error' => 'Method not allowed']);
}

?>