-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 11 sep. 2024 à 22:09
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `food`
--

-- --------------------------------------------------------

--
-- Structure de la table `pl_configs`
--

CREATE TABLE `pl_configs` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `variable` varchar(255) DEFAULT NULL,
  `value` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_configs`
--

INSERT INTO `pl_configs` (`id`, `variable`, `value`) VALUES
(1, 'site_logo', 'uploads/settings/yum-logo.png'),
(2, 'site_title', 'YUM'),
(3, 'site_url', 'https://www.keyce-forum.000webhostapp.com'),
(4, 'site_description', 'Découvrez un monde de délices culinaires en un seul endroit avec YUM ! Notre plateforme innovante rassemble une collection diversifiée de restaurants, cafés et restaurants, vous offrant une expérience culinaire en ligne fluide. Des plats locaux aux cuisines internationales, YUM présente une gamme dynamique d&#039;options alimentaires pour satisfaire toutes les envies.\r\n\r\nAvec YUM, vous pouvez facilement explorer une large sélection de menus, parcourir des plats alléchants et passer facilement vos commandes dans le confort de votre foyer ou de votre bureau. Que vous recherchiez un déjeuner rapide, planifiez un dîner en famille ou organisez une occasion spéciale, YUM est là pour vous.\r\n\r\nNotre plateforme offre une interface conviviale, garantissant une navigation sans tracas et des transactions sécurisées. Découvrez de nouvelles saveurs, lisez les critiques et trouvez des offres et promotions exclusives. YUM est conçu pour répondre à vos goûts et préférences uniques, rendant plus facile que jamais la découverte, la commande et la dégustation de délicieux plats provenant d&#039;une variété de restaurants.\r\n\r\nRejoignez la communauté YUM aujourd&#039;hui et améliorez votre expérience culinaire. Offrez-vous la diversité culinaire, la commodité et la simplicité, le tout réuni en un seul endroit. Avec YUM, satisfaire vos envies n&#039;a jamais été aussi agréable.'),
(5, 'site_keywords', 'Yum, food platform, food delivery, restaurants, restaurant delivery, delivery food online, mcdonalds, meals'),
(6, 'site_image', ''),
(7, 'site_register', '1'),
(8, 'site_forget', '1'),
(9, 'site_smtp_auth', '0'),
(10, 'site_smtp_port', '465'),
(11, 'site_author', 'Puertokhalid'),
(12, 'site_country', 'FR'),
(13, 'site_noreply', 'donotreply@email.com'),
(14, 'fotget_password_msg', ''),
(15, 'email_verification_msg', ''),
(16, 'site_plans', '1'),
(17, 'login_facebook', '1'),
(18, 'login_twitter', '1'),
(19, 'login_google', '1'),
(20, 'login_fbAppId', '7151229091643470'),
(21, 'login_fbAppSecret', 'd2c89459638d8796fa0a98d0072e9229'),
(22, 'login_fbAppVersion', '462.0.0.47.85'),
(23, 'login_twConKey', '3KMlzSL6sNiEnpaXckMIxjDY9'),
(24, 'login_twConSecret', 'yUxMjgAxQAmxQXxYIX1a3W9kCYbWfiIDhi9hNJQjAhAl6RiXo2'),
(25, 'login_ggClientId', '677592769109-uoep4c2f8aknh24cifjhcss08ran0q1r.apps.googleusercontent.com'),
(26, 'login_ggClientSecret', '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'),
(27, 'site_paypal_id', 'Default Application'),
(28, 'site_paypal_live', '0'),
(29, 'site_currency_name', 'EUR'),
(30, 'site_currency_symbol', '€'),
(31, 'site_smtp', '1'),
(32, 'site_smtp_host', 'localhost'),
(33, 'site_smtp_username', ''),
(34, 'site_smtp_password', ''),
(35, 'site_smtp_encryption', 'none'),
(36, 'site_favicon', 'uploads/settings/ZXN0aWFt_1713714447.jpeg'),
(37, 'site_paypal_client_id', 'AaDy1DSrD84wZ4Mxc-hxiPrMHjU55SLeOQwPkZI5mh1thOd3kIi7Zm3naqHCRgMAB-2PlRRIGgbiwcRB'),
(38, 'site_paypal_client_secret', 'EHVmsCUy-owVkSAxPVi3Pil-K5kkPvVVKT5p1HPD8ao3LRm9EP0aUfyKEWw-4mswCz76bb3Vn8LVCCeE'),
(39, 'site_users', '0'),
(40, 'site_facebook', ''),
(41, 'site_twitter', ''),
(42, 'site_instagram', ''),
(43, 'site_youtube', ''),
(44, 'site_skype', ''),
(45, 'taxes', '10'),
(46, 'site_stripe_key', 'pk_test_51PC6jIP8BvwpGtzdku70QkyYwnpTZzpLHE1HP9S63432Sm5k2xXiTekQHFHlmkj2xNbRxfVUGtCJjlDvLczjyZmf00NrAgCBLM'),
(47, 'site_stripe_secret', 'sk_test_51PC6jIP8BvwpGtzd7emsD44ABHZOGPcFjT7g4VuSLYDqhOLm9GgvGfX1qlNwiu24bN8GdnODDSugl1uUmqv8J8Wq00vnW9Gn2f'),
(48, 'ipinfo', '9db5fed4cf44c2');

-- --------------------------------------------------------

--
-- Structure de la table `pl_coupons`
--

CREATE TABLE `pl_coupons` (
  `id` int(11) NOT NULL,
  `coupon_code` varchar(50) NOT NULL,
  `discount_percentage` decimal(5,2) NOT NULL,
  `expiration_date` date DEFAULT NULL,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `restau_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `pl_coupons`
--

INSERT INTO `pl_coupons` (`id`, `coupon_code`, `discount_percentage`, `expiration_date`, `active`, `created_at`, `restau_id`) VALUES
(2, 'CV57XB1', 15.00, '2024-07-10', 0, '2024-05-13 11:10:49', 2),
(3, 'SW92Q5S3', 10.00, '2024-06-21', 0, '2024-05-13 11:18:24', 6),
(21, 'McDX28T5', 20.00, '2024-09-12', 1, '2024-05-25 00:53:33', 5),
(47, 'BK28F79D', 25.00, '2024-06-20', 0, '2024-05-25 02:02:56', 1),
(48, 'BK25O79F', 20.00, '2024-09-21', 1, '2024-09-08 15:28:04', 1);

-- --------------------------------------------------------

--
-- Structure de la table `pl_cuisines`
--

CREATE TABLE `pl_cuisines` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `author` int(11) DEFAULT 0,
  `restaurant_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_cuisines`
--

INSERT INTO `pl_cuisines` (`id`, `name`, `image`, `created_at`, `updated_at`, `author`, `restaurant_id`) VALUES
(1, 'Pizza', 'uploads/users/admin/cuisines/cGl6emE-_1713715831.jpeg', 1713715833, NULL, 1, 2),
(2, 'Burgers', 'uploads/users/admin/cuisines/QnVyZ2Vycw-_1721493430.jpg', 1713715885, 1721493432, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `pl_images`
--

CREATE TABLE `pl_images` (
  `id` int(11) NOT NULL,
  `author` int(11) DEFAULT 0,
  `table_name` varchar(20) DEFAULT NULL,
  `table_id` int(11) DEFAULT 0,
  `created_at` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT 0,
  `url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_images`
--

INSERT INTO `pl_images` (`id`, `author`, `table_name`, `table_id`, `created_at`, `sort`, `url`) VALUES
(1, 1, 'restaurants', 1, 1713717055, 0, 'uploads/users/admin\\c3cd4b055c792dc475f1e65b76568609.jpeg'),
(2, 3, 'restaurants', 6, 1714767040, 0, 'uploads/users/junior\\8d473a8be6f9588e3bb414d21e8725d6.jpeg'),
(3, 3, 'restaurants', 6, 1714767040, 0, 'uploads/users/junior\\874c3c22703d2177d59a50279f7d2786.jpg'),
(4, 3, 'restaurants', 6, 1714767040, 0, 'uploads/users/junior\\4d120542d465583eb3fdcc3a8b539a65.jpg'),
(5, 3, 'restaurants', 6, 1714767040, 0, 'uploads/users/junior\\9d03f5f27deb79f4d4e3f5fc7eb66a80.jpeg');

-- --------------------------------------------------------

--
-- Structure de la table `pl_items`
--

CREATE TABLE `pl_items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `selling_price` varchar(8) DEFAULT NULL,
  `reduce_price` varchar(8) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `restaurant` int(11) DEFAULT 0,
  `menu` int(11) DEFAULT 0,
  `cuisine` int(11) DEFAULT 0,
  `sizes` text DEFAULT NULL,
  `extra` text DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `author` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `instock` tinyint(1) DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `ingredients` varchar(255) DEFAULT NULL,
  `delivery_price` float DEFAULT 0,
  `delivery_time` varchar(50) DEFAULT NULL,
  `home` int(11) DEFAULT 0,
  `item_type` enum('Repas','Boisson','Dessert') DEFAULT NULL,
  `init_price` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_items`
--

INSERT INTO `pl_items` (`id`, `name`, `selling_price`, `reduce_price`, `description`, `restaurant`, `menu`, `cuisine`, `sizes`, `extra`, `created_at`, `updated_at`, `author`, `status`, `instock`, `image`, `ingredients`, `delivery_price`, `delivery_time`, `home`, `item_type`, `init_price`) VALUES
(12, 'Double Cheese Bacon XXL', '4', '7.50', 'Ce sandwich va à l&#039;essentiel. Deux viandes de bœuf grillées à la flamme, des tranches de cheddar fondu et du bacon. Que demander de plus ?', 1, 18, 2, '', '', 1721493944, NULL, 3, 0, 0, 'uploads/users/junior/items/RG91YmUgQ0ggeHhs_1721493939.jpg', 'Pain aux graines de sésame, Rondelles de cornichons, Cheddar fondu (2 tranches), Pain aux graines de sésame, Moutarde, Ketchup, Bacon fumé (3 tranches), Viande grillée à la flamme (Origine France, Allemagne, Autriche ou Irlande), Viande grillée à la flamm', 0, '10-15 min', 1, 'Repas', NULL),
(13, 'Spicy McCrispy', '1.50', '2.59', 'Pour ce grand héros, nous avons décidé d’en rajouter une couche. De la salade croquante, une savoureuse sauce sandwich, de la viande de poulet ultra tendre enrobée d’une panure croustillante, une petite touche de piquant et un pain chaud brioché : il n’en faut pas plus pour obtenir le Spicy McCrispy. Tous nos ingrédients sont frais et de la meilleure qualité – et cela se sent à chaque bouchée.', 5, 19, 2, '', '', 1721496242, NULL, 3, 0, 0, 'uploads/users/junior/items/U3BpY3kgTWNDcmlzcHk-_1721496238.jpg', 'Fromage, Tomates, oignons, Steak..', 0, '10-15 min', 0, 'Repas', NULL),
(14, 'Homestyle Crispy Chicken Curry Bacon', '2', '2.50', 'Plus de goût ? C’est pas possible ! Avec sa portion supplémentaire de bacon Malbuner, tu ajoutes à ton Homestyle Crispy Chicken Curry la touche finale qui te permettra de savourer un burger à la perfection !', 5, 20, 2, '', '', 1721496534, NULL, 3, 0, 0, 'uploads/users/junior/items/SG9tZXN0eWxlQ3Jpc3B5Q2hpY2tlbkN1cnJ5QmFjb24-_1721496532.jpg', 'Fromage, Tomates, oignons, poulets..', 0, '10-15 min', 0, 'Repas', NULL),
(15, 'Homestyle Honey Mustard Veggie', '1.89', '2.89', 'Chez McDonald’s® Suisse, nous savons mettre à l&#039;honneur le végétarien avec le Homestyle Honey Mustard Veggie au goût délicieusement unique. L&#039;escalope végétarienne de Valess est enrobée de panure et frite à la perfection dans de l&#039;huile de colza suisse. C&#039;est pour ça qu&#039;elle devient si parfaitement croustillante et dorée. Les feuilles de salade apportent de la fraîcheur, la tranche d&#039;Emmental suisse et la sauce au miel, à la fois douce et corsée, donnent un goût délicieusement unique. Le tout est servi dans un pain brioché chaud à la farine IP-Suisse.', 5, 21, 2, '', '', 1721496716, NULL, 3, 0, 0, 'uploads/users/junior/items/bWNkb25hbGRzLWhvbWVzdHlsZS1tdXN0YXJkLXZlZ2dpZQ-_1721496704.jpg', 'Fromage, Tomates, oignons, poulets..', 0, '10-15 min', 0, 'Repas', NULL),
(16, 'Happy Meal Cheeseburger', '2.87', '3.79', 'Le Happy Meal® Cheeseburger de McDonald’s® Suisse, c&#039;est le repas rigolo que tous les enfants adorent, et les parents aussi ! En plus d&#039;un Cheeseburger, ton enfant peut composer son menu en choisissant une boisson et un accompagnement. En dessert, il aura une délicieuse compote composée à 100% de fruits. Et cerise sur le gâteau, ton enfant repart avec un jouet ou un livre, histoire de garder un beau souvenir de sa visite.', 5, 22, 2, '', '', 1721496906, NULL, 3, 0, 0, 'uploads/users/junior/items/Y2hlZXNlYnVyZ2VyX1NvbW1lcg-_1721496903.jpg', 'Fromage, Tomates, oignons, poulets..', 0, '10-15 min', 0, 'Repas', NULL),
(17, 'Double Big Mac®', '1.20', '2.80', 'ci, nous avons quasiment créé le double du double : quatre délicieux patties de bœuf t’attendent dans le Double Big Mac®, avec tous les autres ingrédients légendaires d’un véritable Big Mac®. Vas-tu relever le défi et t’attaquer à ce délicieux géant ? Alors, c’est parti : le Double Big Mac® est disponible dans tes restaurants McDonald’s Suisse.', 5, 23, 2, '', '', 1721562000, NULL, 3, 0, 0, 'uploads/users/junior/items/bWNkb25hbGRzLWRvdWJsZS1iaWctbWFj_1721561997.jpg', 'Fromage, Tomates, oignons, steaks beef..', 0, '10-15 min', 0, 'Repas', NULL),
(18, 'Big Mac®', '6.52', '7', 'Le légendaire Big Mac® de McDonald’s à deux étages pour deux fois plus de plaisir. Qu&#039;est-ce qui le rend si bon ? Est-ce que c&#039;est la délicieuse viande de bœuf ? La touche fraîche de la salade verte ? Le croquant des cornichons ? Le fromage fondu ? Le pain chaud à la farine IP-Suisse ? Ou alors la sauce Big Mac® dont nous avons le secret ? Difficile à dire... Ce qu&#039;on sait, c&#039;est qu&#039;il fait le bonheur des grands et des petits depuis des générations !', 5, 23, 2, '', '', 1725804344, NULL, 3, 0, 0, 'uploads/users/junior/items/bWNkb25hbGRzLXByb2R1aXQtYmlnbWFj_1725804342.jpg', 'Steak boeuf-salade-fromage', 0, '10-20 min', 0, 'Repas', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `pl_menus`
--

CREATE TABLE `pl_menus` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `author` int(11) DEFAULT 0,
  `restaurant` int(11) DEFAULT 0,
  `sort` int(11) DEFAULT 0,
  `restaurant_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_menus`
--

INSERT INTO `pl_menus` (`id`, `name`, `created_at`, `updated_at`, `author`, `restaurant`, `sort`, `restaurant_id`) VALUES
(12, 'Menu Test', 1715590186, NULL, 3, 38, 0, 38),
(13, 'Crispy Chicken Cheese', 1721492537, NULL, 3, 1, 0, 1),
(14, 'Classic Cheese &amp; Bacon', 1721492586, NULL, 3, 1, 0, 1),
(15, 'Big Fish', 1721492635, NULL, 3, 1, 0, 1),
(16, 'Steakhouse', 1721492670, NULL, 3, 1, 0, 1),
(17, 'Veggie Whopper', 1721492693, NULL, 3, 1, 0, 1),
(18, 'Double Cheese Bacon XXL', 1721492784, NULL, 3, 1, 0, 1),
(19, 'Spicy McCrispy', 1721495924, NULL, 3, 5, 0, 5),
(20, 'Chicken', 1721496377, 1725805186, 3, 5, 0, 5),
(21, 'Veggie', 1721496620, 1725805129, 3, 5, 0, 5),
(22, 'Happy Meal', 1721496799, 1725805161, 3, 5, 0, 5),
(23, 'Beef', 1721559879, 1725805084, 3, 5, 0, 5);

-- --------------------------------------------------------

--
-- Structure de la table `pl_notifications`
--

CREATE TABLE `pl_notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  `unread` tinyint(4) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `order_id` int(11) DEFAULT NULL,
  `driver_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `pl_notifications`
--

INSERT INTO `pl_notifications` (`id`, `user_id`, `message`, `unread`, `created_at`, `order_id`, `driver_id`) VALUES
(41, 26, 'Your order has been successfully placed', 0, '2024-05-13 12:41:42', NULL, NULL),
(42, 26, 'Your order has been successfully placed', 0, '2024-05-13 15:32:03', NULL, NULL),
(43, 28, 'Your order has been successfully placed', 0, '2024-05-13 15:38:04', NULL, NULL),
(44, 37, 'Your order has been successfully placed', 0, '2024-05-13 16:04:17', NULL, NULL),
(45, 3, 'Your order is being delivered', 0, '2024-05-13 18:35:17', 75, NULL),
(46, 3, 'Your order is being delivered', 0, '2024-05-13 18:35:22', 74, NULL),
(47, 3, 'Your order is being delivered', 0, '2024-05-13 18:49:06', 73, NULL),
(48, 1, 'Your order is being delivered', 0, '2024-05-13 18:54:00', 72, NULL),
(53, 0, 'A new order has been assigned to you.', 0, '2024-05-13 19:45:57', NULL, 32),
(54, 0, 'A new order has been assigned to you.', 0, '2024-05-13 19:46:03', NULL, 31),
(55, 0, 'A new order has been assigned to you.', 0, '2024-05-13 19:46:16', NULL, 32),
(60, 28, 'Your order has been successfully placed', 0, '2024-05-14 19:42:26', NULL, NULL),
(61, 0, 'A new order has been assigned to you.', 0, '2024-05-14 19:45:40', NULL, 32),
(62, 0, 'A new order has been assigned to you.', 0, '2024-05-14 19:45:52', NULL, 31),
(65, 2, 'Your order has been successfully placed', 0, '2024-05-14 20:31:07', NULL, NULL),
(66, 26, 'Your order has been successfully placed', 0, '2024-05-14 20:44:36', NULL, NULL),
(68, 0, 'A new order has been assigned to you.', 0, '2024-05-24 23:54:38', NULL, 31),
(69, 0, 'A new order has been assigned to you.', 0, '2024-05-24 23:59:39', NULL, 31),
(70, 0, 'A new order has been assigned to you.', 0, '2024-05-24 23:59:45', NULL, 31),
(71, 0, 'A new order has been assigned to you.', 0, '2024-05-25 00:00:52', NULL, 31),
(72, 0, 'A new order has been assigned to you.', 0, '2024-05-25 00:00:59', NULL, 31),
(73, 0, 'A new order has been assigned to you.', 0, '2024-05-25 00:01:30', NULL, 31),
(74, 0, 'A new order has been assigned to you.', 0, '2024-05-25 00:01:42', NULL, 31),
(75, 0, 'A new order has been assigned to you.', 0, '2024-05-25 00:02:26', NULL, 31),
(76, 0, 'A new order has been assigned to you.', 0, '2024-05-25 00:02:36', NULL, 31),
(77, 0, 'A new order has been assigned to you.', 0, '2024-05-25 00:03:51', NULL, 31),
(78, 0, 'A new order has been assigned to you.', 0, '2024-05-25 00:17:00', NULL, 31),
(79, 0, 'A new order has been assigned to you.', 0, '2024-05-25 01:47:35', NULL, 31),
(80, 0, 'A new order has been assigned to you.', 0, '2024-05-25 01:48:16', NULL, 31),
(81, 31, 'Your order has been delivered to you !', 0, '2024-05-25 01:50:11', 75, NULL),
(82, 31, 'Your order has been delivered to you !', 0, '2024-05-25 01:50:19', 73, NULL),
(83, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:05:12', NULL, 31),
(84, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:05:18', NULL, 31),
(85, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:05:36', NULL, 31),
(86, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:06:04', NULL, 31),
(87, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:06:25', NULL, 31),
(88, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:07:21', NULL, 31),
(89, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:07:28', NULL, 31),
(90, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:07:33', NULL, 31),
(91, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:07:41', NULL, 31),
(92, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:07:45', NULL, 31),
(93, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:07:51', NULL, 31),
(94, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:08:05', NULL, 31),
(95, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:08:11', NULL, 31),
(96, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:08:47', NULL, 32),
(97, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:08:59', NULL, 32),
(98, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:09:08', NULL, 31),
(99, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:09:18', NULL, 32),
(100, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:09:27', NULL, 31),
(101, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:09:27', NULL, 31),
(102, 0, 'A new order has been assigned to you.', 0, '2024-05-25 02:09:31', NULL, 31),
(103, 28, 'Thank you for your review on BK Test!', 0, '2024-05-29 15:34:49', NULL, NULL),
(104, 0, 'A new order has been assigned to you.', 0, '2024-05-30 15:40:22', NULL, 31),
(106, 3, 'Your order has been delivered to you !', 0, '2024-05-30 16:45:18', 74, NULL),
(107, 28, 'Your order has been successfully placed', 0, '2024-07-20 16:54:06', NULL, NULL),
(108, 0, 'A new order has been assigned to you.', 0, '2024-07-20 16:57:37', NULL, 31),
(109, 31, 'Your order is being delivered', 0, '2024-07-20 16:59:21', 80, NULL),
(110, 28, 'Your order has been successfully placed', 0, '2024-09-05 18:09:06', NULL, NULL),
(111, 0, 'A new order has been assigned to you.', 0, '2024-09-05 18:11:58', NULL, 32),
(112, 0, 'A new order has been assigned to you.', 0, '2024-09-05 18:12:04', NULL, 32),
(113, 0, 'A new order has been assigned to you.', 0, '2024-09-05 18:12:09', NULL, 32),
(114, 0, 'A new order has been assigned to you.', 0, '2024-09-05 18:12:19', NULL, 32),
(115, 0, 'A new order has been assigned to you.', 0, '2024-09-05 18:12:26', NULL, 32),
(116, 3, 'Your order is being delivered', 0, '2024-09-05 18:12:38', 81, NULL),
(117, 32, 'Your order has been delivered to you !', 0, '2024-09-05 18:14:15', 81, NULL),
(118, 3, 'Your order has been successfully placed', 0, '2024-09-08 14:25:04', NULL, NULL),
(119, 31, 'Your order has been delivered to you !', 0, '2024-09-08 15:52:16', 80, NULL),
(120, 31, 'Your order has been delivered to you !', 0, '2024-09-08 15:52:26', 72, NULL),
(121, 0, 'A new order has been assigned to you.', 0, '2024-09-08 15:58:18', NULL, 31),
(122, 31, 'Your order is being delivered', 0, '2024-09-08 15:59:32', 82, NULL),
(123, 28, 'Your order has been successfully placed', 0, '2024-09-10 09:54:01', NULL, NULL),
(124, 0, 'A new order has been assigned to you.', 0, '2024-09-10 09:59:06', NULL, 32),
(125, 32, 'Your order is being delivered', 0, '2024-09-10 10:00:19', 83, NULL),
(126, 32, 'Your order has been delivered to you !', 0, '2024-09-10 10:00:59', 83, NULL),
(127, 3, 'Your order has been delivered to you !', 0, '2024-09-10 10:13:57', 82, NULL),
(128, 3, 'Thank you for your review on Burgers KG!', 0, '2024-09-10 10:15:24', NULL, NULL),
(129, 28, 'Your order has been successfully placed', 0, '2024-09-10 15:36:23', NULL, NULL),
(130, 0, 'A new order has been assigned to you.', 0, '2024-09-10 15:38:12', NULL, 32),
(131, 32, 'Your order is being delivered', 0, '2024-09-10 15:39:16', 84, NULL),
(132, 0, 'A new order has been assigned to you.', 1, '2024-09-10 18:20:55', NULL, 0),
(133, 0, 'A new order has been assigned to you.', 0, '2024-09-10 18:27:11', NULL, 32),
(134, 26, 'Your order has been successfully placed', 0, '2024-09-10 18:33:46', NULL, NULL),
(135, 0, 'A new order has been assigned to you.', 0, '2024-09-10 18:34:39', NULL, 32),
(136, 32, 'Your order is being delivered', 0, '2024-09-10 18:36:56', 85, NULL),
(137, 26, 'Your order has been delivered to you !', 0, '2024-09-10 18:37:45', 85, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `pl_orders`
--

CREATE TABLE `pl_orders` (
  `id` int(11) NOT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `payment_amount` varchar(10) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `invoice_id` varchar(200) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `order_cart` text DEFAULT NULL,
  `billing_info` text DEFAULT NULL,
  `author` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `restaurant` int(11) DEFAULT 0,
  `item` int(11) DEFAULT 0,
  `user` int(11) DEFAULT 0,
  `ip` varchar(50) DEFAULT NULL,
  `os` varchar(50) DEFAULT NULL,
  `browser` varchar(50) DEFAULT NULL,
  `device` varchar(50) DEFAULT NULL,
  `country_name` varchar(50) DEFAULT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `city_name` varchar(50) DEFAULT NULL,
  `delivery_date` int(11) DEFAULT NULL,
  `shipping_date` int(11) DEFAULT NULL,
  `gender` tinyint(1) DEFAULT 0,
  `driver_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_orders`
--

INSERT INTO `pl_orders` (`id`, `transaction_id`, `payment_amount`, `payment_status`, `invoice_id`, `created_at`, `order_cart`, `billing_info`, `author`, `status`, `restaurant`, `item`, `user`, `ip`, `os`, `browser`, `device`, `country_name`, `country_code`, `state`, `city_name`, `delivery_date`, `shipping_date`, `gender`, `driver_id`) VALUES
(72, 'txn_3PG0wzP8BvwpGtzd0cd42A3j', '51.6', 'succeeded', 'tok_1PG0wyP8BvwpGtzdWXR1ES97', 1715614684, '{\"item_id\":\"8\",\"item_size\":\"0\",\"item_quantities\":\"1\",\"item_note\":\"\",\"item_extra\":\"0\",\"item_price\":\"24\",\"item_delivery\":\"5\"}', '{\"name\":\"Loic NGOKOBI\",\"email\":\"loicngokobi4@gmail.com\",\"phone\":\"(+33) 076-202-0131\",\"address\":\"10 rue du General Leclerc\",\"city\":\"Paris\",\"state\":\"Ile-de-France\",\"postal_code\":\"75015\",\"country\":\"FR\",\"gender\":\"1\"}', 28, 2, 6, 8, 3, '::1', 'Windows 10', 'Chrome', 'Computer', 'France', 'FR', 'Île-de-France', 'Paris', 1725810746, 1715626440, 1, 31),
(73, 'txn_3PG0wzP8BvwpGtzd0cd42A3j', '51.6', 'succeeded', 'tok_1PG0wyP8BvwpGtzdWXR1ES97', 1715614684, '{\"item_id\":\"7\",\"item_size\":\"0\",\"item_quantities\":\"1\",\"item_note\":\"\",\"item_extra\":\"0\",\"item_price\":\"20\",\"item_delivery\":\"5\"}', '{\"name\":\"Loic NGOKOBI\",\"email\":\"loicngokobi4@gmail.com\",\"phone\":\"(+33) 076-202-0131\",\"address\":\"10 rue du General Leclerc\",\"city\":\"Paris\",\"state\":\"Ile-de-France\",\"postal_code\":\"75015\",\"country\":\"FR\",\"gender\":\"1\"}', 28, 2, 5, 7, 3, '::1', 'Windows 10', 'Chrome', 'Computer', 'France', 'FR', 'Île-de-France', 'Paris', 1716601819, 1715626146, 1, 31),
(74, 'txn_3PG1MLP8BvwpGtzd0jy14sDG', '148', 'succeeded', 'tok_1PG1MKP8BvwpGtzdApZaif0V', 1715616257, '{\"item_id\":\"8\",\"item_size\":\"0\",\"item_quantities\":\"5\",\"item_note\":\"\",\"item_extra\":\"0\",\"item_price\":\"24\",\"item_delivery\":\"5\"}', '{\"name\":\"Marlu00e8ne SCHIAPPA\",\"email\":\"marlene@gmail.com\",\"phone\":\"0762020131\",\"address\":\"21 rue Georges Auric\",\"city\":\"Paris\",\"state\":\"Ile-de-France\",\"postal_code\":\"75010\",\"country\":\"FR\",\"gender\":\"2\"}', 37, 2, 6, 8, 3, '::1', 'Windows 10', 'Chrome', 'Computer', 'France', 'FR', 'Île-de-France', 'Paris', 1717087518, 1715625322, 2, 31),
(75, 'txn_3PG1MLP8BvwpGtzd0jy14sDG', '148', 'succeeded', 'tok_1PG1MKP8BvwpGtzdApZaif0V', 1715616257, '{\"item_id\":\"5\",\"item_size\":\"0\",\"item_quantities\":\"3\",\"item_note\":\"\",\"item_extra\":\"0\",\"item_price\":\"10\",\"item_delivery\":\"5\"}', '{\"name\":\"Marlu00e8ne SCHIAPPA\",\"email\":\"marlene@gmail.com\",\"phone\":\"0762020131\",\"address\":\"21 rue Georges Auric\",\"city\":\"Paris\",\"state\":\"Ile-de-France\",\"postal_code\":\"75010\",\"country\":\"FR\",\"gender\":\"2\"}', 37, 2, 38, 5, 3, '::1', 'Windows 10', 'Chrome', 'Computer', 'France', 'FR', 'Île-de-France', 'Paris', 1716601811, 1715625317, 2, 31),
(80, 'txn_3PegXwP8BvwpGtzd17cPJ7P0', '15', 'succeeded', 'tok_1PegXwP8BvwpGtzdXtDNtxs4', 1721494446, '{\"item_id\":\"12\",\"item_size\":\"0\",\"item_quantities\":\"3\",\"item_note\":\"Sans Ketchup\",\"item_extra\":\"0\",\"item_price\":\"5\",\"item_delivery\":\"0\"}', '{\"name\":\"Loic NGOKOBI\",\"email\":\"loicngokobi4@gmail.com\",\"phone\":\"(+33) 076-202-0131\",\"address\":\"10 rue du General Leclerc\",\"city\":\"Paris\",\"state\":\"Ile-de-France\",\"postal_code\":\"75016\",\"country\":\"FR\",\"gender\":\"1\"}', 28, 2, 1, 12, 1, '127.0.0.1', 'Windows 10', 'Firefox', 'Computer', 'France', 'FR', 'Île-de-France', 'Paris', 1725810736, 1721494761, 1, 31),
(81, 'txn_3Pvk7GP8BvwpGtzd02pPCNph', '2.87', 'succeeded', 'tok_1Pvk7FP8BvwpGtzdzwJKS8In', 1725559746, '{\"item_id\":\"16\",\"item_size\":\"0\",\"item_quantities\":\"1\",\"item_note\":\"\",\"item_extra\":\"0\",\"item_price\":\"2.87\",\"item_delivery\":\"0\"}', '{\"name\":\"Loic NGOKOBI\",\"email\":\"loicngokobi4@gmail.com\",\"phone\":\"(+33) 076-202-0131\",\"address\":\"10 rue du General Leclerc\",\"city\":\"Paris\",\"state\":\"Ile-de-France\",\"postal_code\":\"75016\",\"country\":\"FR\",\"gender\":\"1\"}', 28, 2, 5, 16, 3, '127.0.0.1', 'Windows 10', 'Firefox', 'Computer', 'France', 'FR', 'Île-de-France', 'Saint-Maur-des-Fossés', 1725560055, 1725559958, 1, 32),
(82, 'txn_3Pwm3BP8BvwpGtzd1PprwyRv', '5', 'succeeded', 'tok_1Pwm3AP8BvwpGtzdXF0sB7qO', 1725805504, '{\"item_id\":\"12\",\"item_size\":\"0\",\"item_quantities\":\"1\",\"item_note\":\"\",\"item_extra\":\"0\",\"item_price\":\"5\",\"item_delivery\":\"0\"}', '{\"name\":\"Junior NGOKOBI\",\"email\":\"junior@yum.fr\",\"phone\":\"0762020131\",\"address\":\"31 rue Paul Meurice\",\"city\":\"Paris\",\"state\":\"IDF\",\"postal_code\":\"75020\",\"country\":\"FR\",\"gender\":\"1\"}', 3, 2, 1, 12, 1, '127.0.0.1', 'Windows 10', 'Firefox', 'Computer', 'France', 'FR', 'Île-de-France', 'Saint-Maur-des-Fossés', 1725963237, 1725811172, 1, 31),
(83, 'txn_3PxQlpP8BvwpGtzd0uCHKFyd', '4', 'succeeded', 'tok_1PxQlnP8BvwpGtzdtqoXs4Gv', 1725962041, '{\"item_id\":\"12\",\"item_size\":\"0\",\"item_quantities\":\"1\",\"item_note\":\"Sans tomate\",\"item_extra\":\"0\",\"item_price\":\"4\",\"item_delivery\":\"0\"}', '{\"name\":\"Loic NGOKOBI\",\"email\":\"loicngokobi4@gmail.com\",\"phone\":\"(+33) 076-202-0131\",\"address\":\"10 rue du General Leclerc\",\"city\":\"Paris\",\"state\":\"Ile-de-France\",\"postal_code\":\"75016\",\"country\":\"FR\",\"gender\":\"1\"}', 28, 2, 1, 12, 1, '::1', 'Windows 10', 'Chrome', 'Computer', 'France', 'FR', 'Île-de-France', 'Paris', 1725962459, 1725962419, 1, 32),
(84, 'txn_3PxW79P8BvwpGtzd0vCWOq32', '4', 'succeeded', 'tok_1PxW77P8BvwpGtzd1f6LjmFF', 1725982583, '{\"item_id\":\"12\",\"item_size\":\"0\",\"item_quantities\":\"1\",\"item_note\":\"\",\"item_extra\":\"0\",\"item_price\":\"4\",\"item_delivery\":\"0\"}', '{\"name\":\"Loic NGOKOBI\",\"email\":\"loicngokobi4@gmail.com\",\"phone\":\"(+33) 076-202-0131\",\"address\":\"10 rue du General Leclerc\",\"city\":\"Paris\",\"state\":\"Ile-de-France\",\"postal_code\":\"75020\",\"country\":\"FR\",\"gender\":\"1\"}', 28, 1, 1, 12, 1, '127.0.0.1', 'Windows 10', 'Firefox', 'Computer', 'France', 'FR', 'Île-de-France', 'Saint-Maur-des-Fossés', NULL, 1725982756, 1, 32),
(85, 'txn_3PxYsoP8BvwpGtzd0xDZne3q', '4', 'succeeded', 'tok_1PxYsoP8BvwpGtzdUEdQujAT', 1725993226, '{\"item_id\":\"12\",\"item_size\":\"0\",\"item_quantities\":\"1\",\"item_note\":\"\",\"item_extra\":\"0\",\"item_price\":\"4\",\"item_delivery\":\"0\"}', '{\"name\":\"Junior Loic Cu00e9dric Expertise Cybersecurity, Cloud, Systems &amp; Networks NGOKOBI\",\"email\":\"kalala@yum.fr\",\"phone\":\"0762020131\",\"address\":\"8 rue de Toulouse\",\"city\":\"Paris, u00cele-de-France\",\"state\":\"Auswu00e4hlen...\",\"postal_code\":\"75019\",\"country\":\"FR\",\"gender\":\"2\"}', 26, 2, 1, 12, 1, '::1', 'Windows 10', 'Chrome', 'Computer', 'France', 'FR', 'Île-de-France', 'Torcy', 1725993465, 1725993416, 2, 32);

-- --------------------------------------------------------

--
-- Structure de la table `pl_pages`
--

CREATE TABLE `pl_pages` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `created_at` int(11) DEFAULT 0,
  `updated_at` int(11) DEFAULT 0,
  `footer` tinyint(1) DEFAULT 0,
  `link` varchar(255) DEFAULT NULL,
  `sort` smallint(6) DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_pages`
--

INSERT INTO `pl_pages` (`id`, `title`, `content`, `created_at`, `updated_at`, `footer`, `link`, `sort`, `keywords`, `description`) VALUES
(3, 'About', 'Qui sommes-nous ?\r\n\r\n\r\nYUM est une entreprise technologique qui met les gens en contact avec les meilleurs dans leurs villes. Pour ce faire, nous donnons aux entreprises locales les moyens d’agir et, à leur tour, nous créons de nouvelles façons pour les gens de gagner leur vie, de travailler et de vivre. Nous avons commencé par faciliter la livraison dans les campus et à domicile, mais nous considérons que ce n’est que le début de la mise en relation des gens avec des possibilités – des soirées plus faciles, des journées plus heureuses, des comptes d’épargne plus importants, des filets plus larges et des communautés plus fortes.\r\n\r\n\r\nOffrir des biens aux clients \r\nAvec vos restaurants préférés à portée de main, YUM satisfait vos envies et vous connecte avec des possibilités - plus de temps et d’énergie pour vous-même et ceux que vous aimez.', 1713708349, 1715515238, 0, NULL, 3, NULL, NULL),
(4, 'Contact', 'You can contact us at contact@yum.fr for your contact questions, opinions, suggestions or skills.\n31 rue Paul Meurice, 75020 Paris, France.\n\nTax Identification Number 1111438512\n0217 232 54 16', 1715514895, 1715515329, 0, NULL, 4, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `pl_payments`
--

CREATE TABLE `pl_payments` (
  `id` int(11) NOT NULL,
  `plan` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_id` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_id` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `token` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `currency` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` int(11) DEFAULT 0,
  `author` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_payments`
--

INSERT INTO `pl_payments` (`id`, `plan`, `payment_id`, `payer_id`, `token`, `price`, `currency`, `status`, `date`, `author`) VALUES
(1, NULL, '1', '2', '123456', 85.00, NULL, '0', 0, 2),
(4, '1', '', '', '', 0.00, NULL, 'completed', 1714690917, 22),
(5, '1', '', '', '', 0.00, NULL, 'completed', 1715437846, 33);

-- --------------------------------------------------------

--
-- Structure de la table `pl_plans`
--

CREATE TABLE `pl_plans` (
  `id` int(11) NOT NULL,
  `plan` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `price` float(10,2) DEFAULT NULL,
  `currency` varchar(5) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc1` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc2` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc3` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc4` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc5` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc6` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc7` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc8` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc9` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT 0,
  `restaurants` int(11) DEFAULT 0,
  `menus` int(11) DEFAULT 0,
  `items` int(11) DEFAULT 0,
  `orders` int(11) DEFAULT 0,
  `export_statistics` tinyint(1) DEFAULT 0,
  `invoices` tinyint(1) DEFAULT 0,
  `statistics` tinyint(1) DEFAULT 0,
  `stripe` tinyint(1) DEFAULT 0,
  `show_ads` tinyint(1) DEFAULT 0,
  `support` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_plans`
--

INSERT INTO `pl_plans` (`id`, `plan`, `price`, `currency`, `desc1`, `desc2`, `desc3`, `desc4`, `desc5`, `desc6`, `desc7`, `desc8`, `desc9`, `created_at`, `restaurants`, `menus`, `items`, `orders`, `export_statistics`, `invoices`, `statistics`, `stripe`, `show_ads`, `support`) VALUES
(1, 'Free Plan', 0.00, '€', '1 Restaurant', '3 Restaurant menus', '6 Restaurant items', '10 Orders a month', 'Paypal payment', 'Statistics', 'Export statistics', 'Invoices', 'Priority support', 0, 1, 3, 3, 3, 0, 0, 0, 0, 0, 0),
(2, 'Basic Plan', 9.99, '€', '3 Restaurant', '6 Restaurant menus', '20 Restaurant items', '20 Orders a month', 'Paypal payment', 'Statistics', 'Export statistics', 'Invoices', 'Priority support', 0, 3, 5, 12, 6, 0, 0, 0, 0, 0, 0),
(3, 'Regular Plan', 19.99, '€', '6 Restaurant', '12 Restaurant menus', '50 Restaurant items', '40 Orders a month', 'Paypal/Stripe payment', 'Statistics', 'Export statistics', 'Invoices', 'Priority support', 0, 8, 10, 18, 10, 1, 1, 1, 1, 1, 1),
(4, 'Pro Plan', 24.99, '€', 'Unlimited Restaurant', 'Unlimited Restaurant menus', 'Unlimited Restaurant items', 'Unlimited Orders a month', 'Paypal/Stripe payment', 'Statistics', 'Export statistics', 'Invoices', 'Priority support', 0, 99999999, 99999999, 99999999, 99999999, 1, 1, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `pl_restaurants`
--

CREATE TABLE `pl_restaurants` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `delivery_time` varchar(20) DEFAULT NULL,
  `delivery_fees` varchar(8) DEFAULT NULL,
  `cuisine` varchar(255) DEFAULT NULL,
  `services` tinyint(1) DEFAULT NULL,
  `country` varchar(3) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `zipcode` varchar(10) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `maps` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `author` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0,
  `facebook` varchar(200) DEFAULT NULL,
  `twitter` varchar(200) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `instagram` varchar(200) DEFAULT NULL,
  `youtube` varchar(200) DEFAULT NULL,
  `working_hours` text DEFAULT NULL,
  `rating` float DEFAULT 0,
  `payment` varchar(10) DEFAULT NULL,
  `latitude` varchar(100) DEFAULT NULL,
  `longitude` varchar(100) DEFAULT NULL,
  `neworders` tinyint(1) DEFAULT 1,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_restaurants`
--

INSERT INTO `pl_restaurants` (`id`, `name`, `phone`, `email`, `delivery_time`, `delivery_fees`, `cuisine`, `services`, `country`, `city`, `state`, `zipcode`, `address`, `maps`, `photo`, `cover`, `created_at`, `updated_at`, `author`, `status`, `facebook`, `twitter`, `website`, `instagram`, `youtube`, `working_hours`, `rating`, `payment`, `latitude`, `longitude`, `neworders`, `user_id`) VALUES
(1, 'Burgers KG', '(+33) 333-302-3762', 'restaurant@burger-king.fr', '20', '', '2', 1, 'FR', 'Paris', 'France', '75015', '25 av Verdun', 'https://www.google.fr/maps/place/Burger+King/@48.9673997,1.560874,11z/data=!4m10!1m2!2m1!1sBurger+King!3m6!1s0x47e6befaebeb2cad:0x8dc3af2d62a882c7!8m2!3d48.9809131!4d1.6923604!15sCgtCdXJnZXIgS2luZyIDiAEBWg0iC2J1cmdlciBraW5nkgEUZmFzdF9mb29kX3Jlc3RhdXJhbnTg', 'uploads/users/admin/restaurants/NDcwNDIzNjE3Ml9lMWZmYjg3ZDZiX28-_1714936393.jpg', '', 1713716269, 1714936398, 1, 0, '', '', NULL, '', '', '{\"1\":[\"9:00 AM\",\"8:00 PM\"],\"2\":[\"9:00 AM\",\"8:00 PM\"],\"3\":[\"9:00 AM\",\"8:00 PM\"],\"4\":[\"9:00 AM\",\"8:00 PM\"],\"5\":[\"9:00 AM\",\"8:00 PM\"],\"6\":[\"9:00 AM\",\"9:00 PM\"],\"7\":[\"10:00 AM\",\"8:00 PM\"]}', 4.5, NULL, '', '', 0, 2),
(2, 'KFC', '(+33) 330-762-0201', 'loicngokobi4@gmail.com', '10 - 20 min', '', '1', 1, 'FR', 'Paris', 'France', '75019', '5 rue du Docteur Potain', '', 'uploads/users/admin/restaurants/S0ZD_1714934977.png', '', 1713720100, 1714935046, 1, 0, '', '', NULL, '', '', '{\"1\":[\"9:00 AM\",\"8:00 PM\"],\"2\":[\"9:00 AM\",\"8:00 PM\"],\"3\":[\"9:00 AM\",\"8:00 PM\"],\"4\":[\"9:00 AM\",\"8:00 PM\"],\"5\":[\"9:00 AM\",\"8:00 PM\"],\"6\":[\"9:00 AM\",\"9:00 PM\"],\"7\":[\"10:00 AM\",\"8:00 PM\"]}', 5, NULL, '', '', 0, 22),
(3, 'Au Bureau', '(+33) 333-306-7923', 'restaurant@au-bureau.fr', '15', '', '1', 3, 'FR', 'Paris', 'France', '51000', '10 rue Sainte-Anne', '', 'uploads/users/junior/restaurants/QXUtYnVyZWF1LWxvZ28-_1715463757.png', '', 1713733278, 1715463761, 3, 0, '', '', NULL, '', '', '{\"1\":[\"12:00 AM\",\"12:00 AM\"],\"2\":[\"1:00 AM\",\"12:00 AM\"],\"3\":[\"12:00 AM\",\"12:00 AM\"],\"4\":[\"12:00 AM\",\"12:00 AM\"],\"5\":[\"12:00 AM\",\"12:00 AM\"],\"6\":[\"12:00 AM\",\"12:00 AM\"],\"7\":[\"9:00 AM\",\"12:00 AM\"]}', 0, NULL, '', '', 1, 0),
(5, 'McDonalds', '(+33) 333-307-6202', 'restaurant@mcdonalds.fr', '10', '', '2,1', 1, 'FR', 'Paris', 'Ile-de-France', '75012', '10 rue Sainte-Anne', '', 'uploads/users/admin/restaurants/TWNEb25hbGRzLUxvZ28tMg-_1714935498.png', '', 1714226133, 1714935506, 3, 0, '', '', NULL, '', '', '{\"1\":[\"9:00 AM\",\"8:00 PM\"],\"2\":[\"9:00 AM\",\"8:00 PM\"],\"3\":[\"9:00 AM\",\"8:00 PM\"],\"4\":[\"9:00 AM\",\"8:00 PM\"],\"5\":[\"9:00 AM\",\"8:00 PM\"],\"6\":[\"9:00 AM\",\"9:00 PM\"],\"7\":[\"10:00 AM\",\"8:00 PM\"]}', 4.33333, NULL, '', '', 0, 23),
(6, 'SUBWAY', '(+33) 330-762-0232', 'subway@yum.fr', '10-15 min', '', '2,1', 1, 'FR', 'Paris', 'IDF', '75016', '12 rue Vitor Hugo', '', 'uploads/users/admin/restaurants/U3Vid2F5LUxvZ28-_1714935265.jpg', '', 1714766877, 1714935269, 3, 0, '', '', NULL, '', '', '{\"1\":[\"9:00 AM\",\"8:00 PM\"],\"2\":[\"9:00 AM\",\"8:00 PM\"],\"3\":[\"9:00 AM\",\"8:00 PM\"],\"4\":[\"9:00 AM\",\"8:00 PM\"],\"5\":[\"9:00 AM\",\"8:00 PM\"],\"6\":[\"9:00 AM\",\"9:00 PM\"],\"7\":[\"10:00 AM\",\"8:00 PM\"]}', 0, NULL, '', '', 0, 0),
(38, 'BK Test', '(+33) 076-202-0131', 'loicngokobi4@gmail.com', '15', '', '2,1', 1, 'FR', 'Meulon', 'IDF', '77200', '17 rue Relecq-Kerhuon', '', 'uploads/users/junior/restaurants/Qks-_1715437469.jpeg', NULL, 1715437605, NULL, 3, 0, '', '', NULL, '', '', '', 4, NULL, '', '', 0, 33);

-- --------------------------------------------------------

--
-- Structure de la table `pl_reviews`
--

CREATE TABLE `pl_reviews` (
  `id` int(11) NOT NULL,
  `author` int(11) DEFAULT 0,
  `user` int(11) DEFAULT 0,
  `restaurant` int(11) DEFAULT 0,
  `item` int(11) DEFAULT 0,
  `content` text DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `stars` tinyint(1) DEFAULT 0,
  `created_at` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_reviews`
--

INSERT INTO `pl_reviews` (`id`, `author`, `user`, `restaurant`, `item`, `content`, `title`, `stars`, `created_at`) VALUES
(1, 3, 23, 5, 3, 'Très satisfait. Livraison hyper rapide', 'McDonald&#039;s The best', 5, 1714688377),
(3, 28, 1, 1, 1, 'Un vrai regal ! Livraison ultra rapide et sercice au soins. 10/10\r\nJe recommande !!!!!', 'Merci Burger King !!!', 5, 1715431021),
(4, 28, 23, 5, 3, 'Livraison reçue en retard. Sinon le repas reste de bonne qualité comme toujours.', 'Burger chez McDonalds', 3, 1715431345),
(10, 28, 1, 2, 2, 'Un délice vos repas. Merci pour  la vitesse de livraison', 'Thank U KFC', 5, 1715473329),
(12, 3, 3, 1, 12, 'Livraison rapide ! Je recommande :)', 'Commande BK', 4, 1725963324);

-- --------------------------------------------------------

--
-- Structure de la table `pl_subscribers`
--

CREATE TABLE `pl_subscribers` (
  `id` int(11) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `created_at` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_subscribers`
--

INSERT INTO `pl_subscribers` (`id`, `email`, `content`, `created_at`) VALUES
(1, 'loicngokobi4@gmail.com', NULL, 1713558477),
(2, 'loicngokobi@cezham.online', NULL, 1713715376);

-- --------------------------------------------------------

--
-- Structure de la table `pl_taxes`
--

CREATE TABLE `pl_taxes` (
  `id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT 0,
  `taxes` float DEFAULT 0,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_taxes`
--

INSERT INTO `pl_taxes` (`id`, `order_id`, `taxes`, `created_at`) VALUES
(68, 0, 4.34, 1715614324),
(69, 0, 1.5, 1715614328),
(70, 0, 2.5, 1715614332),
(71, 0, 2.9, 1715614684),
(72, 0, 2.5, 1715614688),
(73, 0, 12.5, 1715616257),
(74, 0, 3.5, 1715616261),
(75, 0, 4.82, 1715715746),
(76, 0, 2.5, 1715715750),
(77, 0, 2.2496, 1715718667),
(78, 0, 12.5, 1715719476),
(79, 0, 1.5, 1721494446),
(80, 0, 0.287, 1725559746),
(81, 0, 0.5, 1725805504),
(82, 0, 0.4, 1725962041),
(83, 0, 0.4, 1725982583),
(84, 0, 0.4, 1725993226);

-- --------------------------------------------------------

--
-- Structure de la table `pl_testimonials`
--

CREATE TABLE `pl_testimonials` (
  `id` int(11) NOT NULL,
  `author` int(11) DEFAULT 0,
  `content` text DEFAULT NULL,
  `created_at` int(11) DEFAULT 0,
  `status` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_testimonials`
--

INSERT INTO `pl_testimonials` (`id`, `author`, `content`, `created_at`, `status`) VALUES
(3, 3, 'Chers étudiants,\r\n\r\nBienvenue chez YUM, votre restaurant dédié. Notre mission : vous offrir une cuisine délicieuse et un lieu chaleureux où vous retrouver entre amis. Venez profiter de plats savoureux à prix abordables et d&#039;une ambiance conviviale. À bientôt chez YUM !', 1713714951, 1),
(5, 1, 'Chez YUM, votre satisfaction est notre priorité. Venez découvrir une cuisine délicieuse dans une ambiance conviviale. À bientôt chez nous !', 1713715284, 1),
(6, 2, 'Cher Yummer, \r\nNous sommes ravis d&#039;utiliser YUM pour notre restaurant Burger King. Grâce à cette plateforme, nous avons pu augmenter notre visibilité auprès des étudiants, simplifier le processus de commande, personnaliser les repas et améliorer notre efficacité opérationnelle. Le support client de YUM est également excellent. Nous recommandons vivement YUM à tous les restaurants dédiés aux étudiants.\r\n\r\nL&#039;équipe Burger King.', 1714841648, 1);

-- --------------------------------------------------------

--
-- Structure de la table `pl_users`
--

CREATE TABLE `pl_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `level` enum('1','2','4','6') DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `socials` varchar(255) DEFAULT NULL,
  `social_id` varchar(255) DEFAULT NULL,
  `social_name` varchar(255) DEFAULT NULL,
  `gender` tinyint(1) UNSIGNED DEFAULT 0,
  `country` varchar(3) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `state` varchar(150) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `birth` varchar(255) DEFAULT NULL,
  `statistics` text DEFAULT NULL,
  `moderat` varchar(255) DEFAULT '0',
  `verified` tinyint(1) UNSIGNED DEFAULT 0,
  `balance` float UNSIGNED DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `language` tinyint(1) UNSIGNED DEFAULT NULL,
  `updated_at` int(10) UNSIGNED DEFAULT NULL,
  `trash` tinyint(1) UNSIGNED NOT NULL DEFAULT 0,
  `plan` tinyint(1) DEFAULT 0,
  `txn_id` varchar(200) DEFAULT NULL,
  `lastpayment` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `availability` enum('0','1') DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_users`
--

INSERT INTO `pl_users` (`id`, `firstname`, `lastname`, `username`, `password`, `photo`, `cover`, `date`, `level`, `email`, `socials`, `social_id`, `social_name`, `gender`, `country`, `city`, `state`, `address`, `birth`, `statistics`, `moderat`, `verified`, `balance`, `description`, `language`, `updated_at`, `trash`, `plan`, `txn_id`, `lastpayment`, `phone`, `availability`) VALUES
(1, NULL, NULL, 'admin', '20eabe5d64b0e216796e834f52d61fd0b70332fc', NULL, NULL, 1713452030, '6', 'admin@gmail.com', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 432.351, NULL, NULL, NULL, 0, 1, NULL, 1714687926, NULL, ''),
(2, 'Cédric', 'NGOKOBI', 'Cédric', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'uploads/users/cedric/profile/NDcwNDIzNjE3Ml9lMWZmYjg3ZDZiX28-_1714829614.jpg', NULL, 1713482024, '4', 'cedric@yum.fr', NULL, NULL, NULL, 1, 'FR', 'Paris', 'Ile-de-France', '8 rue de Toulouse', NULL, NULL, '0', 0, 0, NULL, NULL, 1714829618, 0, 0, NULL, NULL, '(+33) 067-923-4595', '1'),
(3, 'Junior', 'NGOKOBI', 'Junior', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', NULL, 1713708600, '6', 'junior@yum.fr', NULL, NULL, NULL, 1, 'FR', '', '', '2 rue de la Paix', NULL, NULL, '0', 0, 346.369, NULL, NULL, 1725805731, 0, 3, NULL, 1714688565, '', ''),
(22, '', '', 'Patrick', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'uploads/users/patrick/profile/S0ZD_1714839450.png', NULL, 1714224111, '4', 'patrick@yum.fr', NULL, NULL, NULL, 0, 'AF', '', '', '', NULL, NULL, '0', 0, 0, NULL, NULL, 1714839454, 0, 0, NULL, 1714690917, '', ''),
(23, '', '', 'John', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'uploads/users/john/profile/bWNk_1714839071.jpeg', NULL, 1714224192, '4', 'john@yum.fr', NULL, NULL, NULL, 0, 'AF', '', '', '', NULL, NULL, '0', 0, 0, NULL, NULL, 1714839074, 0, 0, NULL, NULL, '', ''),
(26, '', '', 'kalakala', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', NULL, 1714229718, '1', 'kalala@yum.fr', NULL, NULL, NULL, 0, 'AF', '', '', '', NULL, NULL, '0', 0, 0, NULL, NULL, 1714727643, 0, 4, NULL, NULL, '', '0'),
(31, 'Thomas', 'ARMAND', 'Thomas', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', NULL, 1715084913, '2', 'thomas@driver-yum.fr', NULL, NULL, NULL, 1, 'FR', '', '', '', NULL, NULL, '0', 0, 0, NULL, NULL, 1715172926, 0, 0, NULL, NULL, '', '0'),
(28, 'Loic', 'NGOKOBI', 'Loic', '1984a94171d432d6b57255b59045094904bbe45a', 'https://lh3.googleusercontent.com/a/ACg8ocIA21l7NR0-NvvtEO_I9u93ZcpnK_J7lTduE06D91FwgUXGF8HU=s96-c', NULL, 1715003558, '1', 'loicngokobi4@gmail.com', NULL, '115735153325061130851', 'google', 1, 'FR', 'Paris', 'Ile-de-France', '10 rue du General Leclerc', NULL, NULL, '0', 0, 0, NULL, NULL, 1721491911, 0, 0, NULL, NULL, '(+33) 076-202-0131', '0'),
(32, NULL, NULL, 'Clement', '7c4a8d09ca3762af61e59520943dc26494f8941b', NULL, NULL, 1715172771, '2', 'clement@driver-yum.fr', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, '1'),
(33, '', '', 'Emilie', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', NULL, 1715421861, '4', 'emilie@restau-yum.fr', NULL, NULL, NULL, 2, 'AF', '', '', '', NULL, NULL, '0', 0, 0, NULL, NULL, 1715438840, 0, 1, NULL, 1715437846, '', '1'),
(36, NULL, NULL, 'Test', '7c4a8d09ca3762af61e59520943dc26494f8941b', NULL, NULL, 1715424353, '4', 'test@yum.fr', NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, '0', 0, 0, NULL, NULL, NULL, 0, 0, NULL, NULL, NULL, '1'),
(37, 'Marlène', 'NEJ', 'Marlène', '7c4a8d09ca3762af61e59520943dc26494f8941b', '', NULL, 1715615951, '1', 'marlene@gmail.com', NULL, NULL, NULL, 2, 'FR', 'Paris', 'Ile-de-France', '12 av Jean Jaurès', NULL, NULL, '0', 0, 0, NULL, NULL, 1725811046, 0, 0, NULL, NULL, '(+33) 076-202-0131', '1');

-- --------------------------------------------------------

--
-- Structure de la table `pl_withdraws`
--

CREATE TABLE `pl_withdraws` (
  `id` int(11) NOT NULL,
  `author` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `accepted_at` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 0,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `pl_withdraws`
--

INSERT INTO `pl_withdraws` (`id`, `author`, `price`, `created_at`, `accepted_at`, `status`, `email`) VALUES
(1, 3, 4, 1714690843, 1714691456, 1, 'loicngokobi4@gmail.com'),
(2, 1, 80, 1714765728, 1715620846, 2, 'admin@gmail.com'),
(3, 1, 265.52, 1715620790, 1717335375, 1, 'loicngokobi4@gmail.com'),
(4, 3, 240, 1717333568, 1717335381, 1, 'junior@yum.fr');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `pl_configs`
--
ALTER TABLE `pl_configs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_coupons`
--
ALTER TABLE `pl_coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupon_code` (`coupon_code`),
  ADD KEY `fk_coupon_restau` (`restau_id`);

--
-- Index pour la table `pl_cuisines`
--
ALTER TABLE `pl_cuisines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cuisine_restaurant` (`restaurant_id`);

--
-- Index pour la table `pl_images`
--
ALTER TABLE `pl_images`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_items`
--
ALTER TABLE `pl_items`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_menus`
--
ALTER TABLE `pl_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_menu_restaurant` (`restaurant_id`);

--
-- Index pour la table `pl_notifications`
--
ALTER TABLE `pl_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_notification_order` (`order_id`);

--
-- Index pour la table `pl_orders`
--
ALTER TABLE `pl_orders`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_pages`
--
ALTER TABLE `pl_pages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_payments`
--
ALTER TABLE `pl_payments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_plans`
--
ALTER TABLE `pl_plans`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_restaurants`
--
ALTER TABLE `pl_restaurants`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_reviews`
--
ALTER TABLE `pl_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_subscribers`
--
ALTER TABLE `pl_subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_taxes`
--
ALTER TABLE `pl_taxes`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_testimonials`
--
ALTER TABLE `pl_testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_users`
--
ALTER TABLE `pl_users`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pl_withdraws`
--
ALTER TABLE `pl_withdraws`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `pl_configs`
--
ALTER TABLE `pl_configs`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT pour la table `pl_coupons`
--
ALTER TABLE `pl_coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT pour la table `pl_cuisines`
--
ALTER TABLE `pl_cuisines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `pl_images`
--
ALTER TABLE `pl_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `pl_items`
--
ALTER TABLE `pl_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT pour la table `pl_menus`
--
ALTER TABLE `pl_menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT pour la table `pl_notifications`
--
ALTER TABLE `pl_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT pour la table `pl_orders`
--
ALTER TABLE `pl_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT pour la table `pl_pages`
--
ALTER TABLE `pl_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `pl_payments`
--
ALTER TABLE `pl_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `pl_plans`
--
ALTER TABLE `pl_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `pl_restaurants`
--
ALTER TABLE `pl_restaurants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT pour la table `pl_reviews`
--
ALTER TABLE `pl_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `pl_subscribers`
--
ALTER TABLE `pl_subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `pl_taxes`
--
ALTER TABLE `pl_taxes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT pour la table `pl_testimonials`
--
ALTER TABLE `pl_testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `pl_users`
--
ALTER TABLE `pl_users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT pour la table `pl_withdraws`
--
ALTER TABLE `pl_withdraws`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `pl_coupons`
--
ALTER TABLE `pl_coupons`
  ADD CONSTRAINT `fk_coupon_restau` FOREIGN KEY (`restau_id`) REFERENCES `pl_restaurants` (`id`);

--
-- Contraintes pour la table `pl_cuisines`
--
ALTER TABLE `pl_cuisines`
  ADD CONSTRAINT `fk_cuisine_restaurant` FOREIGN KEY (`restaurant_id`) REFERENCES `pl_restaurants` (`id`);

--
-- Contraintes pour la table `pl_menus`
--
ALTER TABLE `pl_menus`
  ADD CONSTRAINT `fk_menu_restaurant` FOREIGN KEY (`restaurant_id`) REFERENCES `pl_restaurants` (`id`);

--
-- Contraintes pour la table `pl_notifications`
--
ALTER TABLE `pl_notifications`
  ADD CONSTRAINT `fk_notification_order` FOREIGN KEY (`order_id`) REFERENCES `pl_orders` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
