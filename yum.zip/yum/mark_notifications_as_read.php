<?php

// Connexion à la base de données
include __DIR__."/configs.php";

$userId = us_id;
$driverId = us_id;

// Début de la transaction
$db->begin_transaction();

// Requête 1 : Marquer toutes les notifications de l'utilisateur comme lues
$sql1 = "UPDATE pl_notifications SET unread = 0 WHERE user_id = ? OR driver_id = ?";
$stmt1 = $db->prepare($sql1);
$stmt1->bind_param("ii", $userId, $driverId);
$stmt1->execute();

// Requête 2 : Marquer toutes les notifications de l'utilisateur comme lues (autre méthode)
$sql2 ="UPDATE pl_notifications
        JOIN pl_orders ON pl_orders.id = pl_notifications.order_id
        SET pl_notifications.unread = 0
        WHERE pl_orders.author = ?";

$stmt2 = $db->prepare($sql2);
$stmt2->bind_param("i", $userId);
$stmt2->execute();

// Valider la transaction
$db->commit();

// Fermer les requêtes
$stmt1->close();
$stmt2->close();

// Fermer la connexion à la base de données
$db->close();

// Réponse JSON pour indiquer le succès
header('Content-Type: application/json');
echo json_encode(['success' => true]);

?>
