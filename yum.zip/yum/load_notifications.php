<?php
// Connexion à la base de données
include __DIR__."/configs.php";

$db->begin_transaction();
$userId = us_id;

// Première requête
$sql1 = "SELECT * FROM pl_notifications WHERE (user_id = ? AND unread = 1 AND order_id IS NULL) OR (driver_id = ? AND unread = 1)";
$stmt1 = $db->prepare($sql1);
$stmt1->bind_param("ii", $userId, $userId);
$stmt1->execute();
$result1 = $stmt1->get_result();

// Deuxième requête
$sql2 = "SELECT *
FROM pl_notifications AS n
JOIN pl_orders AS o ON n.order_id = o.id
WHERE o.author = ? AND unread = 1";
$stmt2 = $db->prepare($sql2);
$stmt2->bind_param("i", $userId);
$stmt2->execute();
$result2 = $stmt2->get_result();

// Valider la transaction
$db->commit();

// Récupérer les résultats de la première requête
$notifications1 = [];
while ($row = $result1->fetch_assoc()) {
    $notifications1[] = $row;
}

// Récupérer les résultats de la deuxième requête
$notifications2 = [];
while ($row = $result2->fetch_assoc()) {
    $notifications2[] = $row;
}

// Fermer les requêtes
$stmt1->close();
$stmt2->close();

// Fermer la connexion à la base de données
$db->close();

// Fusionner les résultats des deux requêtes
$notifications = array_merge($notifications1, $notifications2);

// Renvoyer les notifications au format JSON
header('Content-Type: application/json');
echo json_encode($notifications);

?>

