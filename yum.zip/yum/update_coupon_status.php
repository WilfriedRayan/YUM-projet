<?php
// update_coupon_status.php

// Connexion à la base de données
include __DIR__."/configs.php";

// Requêtes de mise à jour
$sql1 = "UPDATE pl_coupons SET active = 0 WHERE expiration_date < CURRENT_DATE AND active = 1";
$sql2 = "UPDATE pl_coupons SET active = 1 WHERE expiration_date > CURRENT_DATE AND active = 0";

$response = ['status' => 'success', 'messages' => []];

// Exécuter la première requête
if ($db->query($sql1) !== TRUE) {
    $response['status'] = 'error';
    $response['messages'][] = 'Erreur lors de la mise à jour des coupons inactifs: ' . $db->error;
}

// Exécuter la deuxième requête
if ($db->query($sql2) !== TRUE) {
    $response['status'] = 'error';
    $response['messages'][] = 'Erreur lors de la mise à jour des coupons actifs: ' . $db->error;
}

// Retourner la réponse
echo json_encode($response);

$db->close();
?>