<?php

include __DIR__."/configs.php";

// Vérifier si la requête est une requête POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifier si la variable POST "availability" est définie
    if (isset($_POST['availability'])) {
        // Récupérer la nouvelle valeur de disponibilité depuis la requête POST
        $availability = $_POST['availability'];
        $user_id = us_id;

        // Mettre à jour la disponibilité dans la base de données
        // Supposons que vous ayez une table "users" avec une colonne "availability" représentant la disponibilité
        // Vous pouvez exécuter une requête SQL pour mettre à jour cette colonne
        $sql = "UPDATE pl_users SET availability = ? WHERE id = ?"; // Remplacez "users" par le nom de votre table et "user_id" par l'identifiant de l'utilisateur
        $stmt = $db->prepare($sql);
        $stmt->execute([$availability, $user_id]); // Remplacez $user_id par l'identifiant de l'utilisateur dont vous souhaitez mettre à jour la disponibilité

        // Vérifier si la mise à jour a réussi
        if ($stmt->rowCount() > 0) {
            // La mise à jour a réussi
            echo 'Availability updated successfully.';
        } else {
            // La mise à jour a échoué
            echo 'Failed to update availability.';
        }
    } else {
        // La variable POST "availability" n'est pas définie
        echo 'Availability parameter missing.';
    }
} else {
    // La requête n'est pas une requête POST
    echo 'Method not allowed.';
}
?>
