<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $couponCode = isset($_POST['couponCode']) ? sc_sec($_POST['couponCode']) : '';
    $percentage = isset($_POST['percentage']) ? sc_sec($_POST['percentage']) : '';
    $resto = isset($_POST['resto']) ? sc_sec($_POST['resto']) : '';
    $expDate = isset($_POST['exp_date']) ? sc_sec($_POST['exp_date']) : '';

    $sql = "INSERT INTO pl_coupons (coupon_code, discount_percentage, restau_id, expiration_date) VALUES (?, ?, ?, ?)";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("ssis", $couponCode, $percentage, $resto, $expDate);

    if ($stmt->execute()) {
        echo "<div class='success-message'>Coupon successfully added</div>";       
        
    } else {
        echo "<div class='error-message'>An error occurred while adding the coupon.</div>";
    }

    // Rafraîchir la page actuelle
    echo "<script>
        window.addEventListener('load', function() {
            setTimeout(function() {
                window.location.href = '" . $_SERVER['REQUEST_URI'] . "';
            }, 3000);
        });
    </script>";
    exit;

}

if(isset($_GET['user_id']) || isset($_GET['restau_id']) || isset($_GET['driver_id'])) {
    // Récupérez l'ID de l'utilisateur depuis les paramètres de l'URL
    $userId = $_GET['user_id'];
	$driverId = $_GET['driver_id'];
    $restaurantId = $_GET['restau_id'];

    $driverId = us_id;
    //echo "L'ID de l'utilisateur est : " . $userId;
} else {
    // Gérer le cas où l'ID de l'utilisateur n'est pas présent dans l'URL
    //echo "ID d'utilisateur ou ID de restaurant non trouvé dans l'URL";
}


?>

<style>

.success-message {
            padding: 10px;
            background-color: #dff0d8;
            color: #3c763d;
            border: 1px solid #d6e9c6;
        }

        .error-message {
            padding: 10px;
            background-color: #f2dede;
            color: #a94442;
            border: 1px solid #ebccd1;
        }
</style>

<?php if(us_level == 6): ?>

    <form method="POST" action="">
    <div class="pt-resaurants pt-restaurantspage">
        <div class="pt-resaurant">
            <div class="form-row">
                <div class="col">
                    <div class="form-group">
                        <label>Coupon Code <b class="text-danger small">*</b></label>
                        <input type="text" name="couponCode" placeholder="Coupon code" required>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label>Discount Percentage</label>
                        <input type="number" name="percentage" step="1" min="1" placeholder="Percentage" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label>For the restaurant <b class="text-danger small">*</b></label>
                <select class="select-resto" data-live-search="true" data-width="100%" name="resto" title="Receiving restaurant...">
                    <?php 
                    $sql_r = $db->query("SELECT * FROM pl_restaurants ORDER BY name ASC");
                    if($sql_r->num_rows):
                        while($rs_r = $sql_r->fetch_assoc()):
                            ?>
                            <option data-tokens="<?=$rs_r['name']?>" value="<?=$rs_r['id']?>"<?=($rs_r['id'] ? 'selected' : '')?>><?=$rs_r['name']?></option>
                            <?php
                        endwhile;
                        $sql_r->close();
                    endif;
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Expiration Date</label>
                <input type="text" name="exp_date" placeholder="2024-07-25" required>
            </div>

            <div class="pt-msg"></div>

            <div class="modal-footer">
                <button type="submit" class="pt-btn" onclick="showSuccessNotification('New coupon !')"><?=$lang['restaurant']['btn']?></button>
            </div>
        </div>
    </div>

</form>

<?php elseif(us_level == 4) : ?>

    <form method="POST" action="">
    <div class="pt-resaurants pt-restaurantspage">
        <div class="pt-resaurant">
            <div class="form-row">
                <div class="col">
                    <div class="form-group">
                        <label>Coupon Code <b class="text-danger small">*</b></label>
                        <input type="text" name="couponCode" placeholder="Coupon code" required>
                    </div>
                </div>
                <div class="col">
                    <div class="form-group">
                        <label>Discount Percentage</label>
                        <input type="number" name="percentage" step="1" min="1" placeholder="Percentage" required>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label>For the restaurant <b class="text-danger small">*</b></label>
                <select class="select-resto" data-live-search="true" data-width="100%" name="resto" title="Receiving restaurant...">
                    <?php 
                    $sql_r = $db->query("SELECT * FROM pl_restaurants WHERE user_id = '" . us_id ."' ORDER BY name ASC");
                    if($sql_r->num_rows):
                        while($rs_r = $sql_r->fetch_assoc()):
                            ?>
                            <option data-tokens="<?=$rs_r['name']?>" value="<?=$rs_r['id']?>"<?=($rs_r['id'] ? 'selected' : '')?>><?=$rs_r['name']?></option>
                            <?php
                        endwhile;
                        $sql_r->close();
                    endif;
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label>Expiration Date</label>
                <input type="text" name="exp_date" placeholder="2024-07-25" required>
            </div>

            <div class="pt-msg"></div>

            <div class="modal-footer">
                <button type="submit" class="pt-btn" onclick="showSuccessNotification('New coupon !')"><?=$lang['restaurant']['btn']?></button>
            </div>
        </div>
    </div>

</form>

<?php endif; ?>

<!---------------------------Script JS-------------------------------------------->

<script>

// Fonction pour afficher une notification de succès
function showSuccessNotification(message) {
    // Vérifiez si le navigateur prend en charge les notifications
    if ('Notification' in window) {
        // Vérifiez si les notifications sont autorisées
        if (Notification.permission === 'granted') {
            // Créez une notification
            new Notification('Success', { body: message });
        } else if (Notification.permission !== 'denied') {
            // Demandez la permission à l'utilisateur pour afficher les notifications
            Notification.requestPermission().then(function(permission) {
                if (permission === 'granted') {
                    // Créez une notification si la permission est accordée
                    new Notification('Success', { body: message });
                }
            });
        }
    }
}

function refreshPage() {
    location.reload(true);
}  

</script>