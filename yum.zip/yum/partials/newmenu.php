<?php

if( page == "dashboard" || page == "restau_dashboard"){
	$sql_where = "";
	$form_modal = true;
} else {
	$sql_where = "WHERE author = '".us_id."'";
	$form_modal = true;
}

if(isset($_GET['user_id']) && isset($_GET['restau_id'])) {
    // Récupérez l'ID de l'utilisateur depuis les paramètres de l'URL
    $userId = $_GET['user_id'];
    $restaurantId = $_GET['restau_id'];
    
    // Maintenant vous pouvez effectuer des manipulations avec $userId et $restaurantId
    //echo "L'ID de l'utilisateur est : " . $userId;
} else {
    // Gérer le cas où l'ID de l'utilisateur n'est pas présent dans l'URL
    //echo "ID d'utilisateur ou ID de restaurant non trouvé dans l'URL";
}

?>
<form id="sendmenu">
<div class="modal fade newmodal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title"><?=$lang['restaurant']['new_menu']?></h4>
        <button type="button" class="close" data-dismiss="modal">×</button>
      </div>

      <div class="modal-body">
				<div class="form-row">
					<div class="col">
						<div class="form-group">
							<label><?=$lang['restaurant']['menu_name']?> <small class="text-danger">*</small></label>
							<input type="text" name="name" placeholder="<?=$lang['restaurant']['menu_name']?>">
						</div>
					</div>
					<div class="col">
						<div class="form-group">
							<label><?=$lang['restaurant']['menu_restaurant']?> <small class="text-danger">*</small></label>
						<select class="selectpicker" data-live-search="true" data-width="100%" name="rest" title="<?=$lang['restaurant']['menu_restaurant_l']?>">
    <?php
    if(us_level == 4){
        $sql = $db->query("SELECT id, name FROM pl_restaurants WHERE id=$restaurantId");
        if($sql->num_rows > 0) {
            while($rs = $sql->fetch_assoc()) {
                // Traitement des données ici
                ?> 
                <option data-tokens="<?=$rs['name']?>" value="<?=$rs['id']?>"><?=$rs['name']?></option>
                <?php
            }
        } else {
            echo("Aucun restaurant trouvé pour cet identifiant !");
        }
    } elseif(us_level == 6) {
        $sql = $db->query("SELECT id, name FROM ".prefix."restaurants {$sql_where} ORDER BY name ASC");
        if($sql->num_rows > 0) {
            while($rs = $sql->fetch_assoc()) {
                // Traitement des données ici
                ?> 
                <option data-tokens="<?=$rs['name']?>" value="<?=$rs['id']?>"><?=$rs['name']?></option>
                <?php
            }
        } else {
            echo("Aucun restaurant trouvé pour cet identifiant !");
        }
    } else {
        echo("Something is going wrong !");
    }
    $sql->close();
    ?>
</select>

						</div>
					</div>
				</div>

				<div class="pt-msg"></div>
      </div>

      <div class="modal-footer">
				<input type="hidden" name="id">
        <button type="submit" class="pt-btn"><?=$lang['restaurant']['btn']?></button>
      </div>

    </div>
  </div>
</div>
</form>
