<?php

include __DIR__."/configs.php";

// Exemple de requête pour charger les conducteurs depuis la base de données
$query = "SELECT id, username FROM pl_users WHERE (level= 2 AND availability= '1')";
$result = $db->query($query);

if ($result) {
    $drivers = array();
    while ($row = $result->fetch_assoc()) {
        $drivers[] = $row;
    }
    echo json_encode($drivers);
    echo json_encode(array('error' => 'Unable to load drivers'));
} else {
    echo json_encode(array('error' => 'Unable to load drivers'));
}
?>
