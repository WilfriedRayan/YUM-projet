<?php

include __DIR__."/head.php";
// Exécuter la requête SQL pour obtenir l'ID du restaurant
$result = $db->query("SELECT id, name FROM pl_restaurants WHERE user_id = '".us_id."'");

// Vérifier si la requête a réussi
if ($result) {
    // Extraire la ligne résultante
    $row = $result->fetch_assoc();

    // Vérifier si une ligne a été trouvée
    if ($row) {
        // Récupérer l'ID du restaurant
        $restaurantName = $row['name'];
		$restaurantId = $row['id'];
    } else {
        // Gérer le cas où aucun restaurant n'a été trouvé pour l'utilisateur
        //echo "Aucun restaurant trouvé pour cet utilisateur.";
    }
} else {
    // Gérer les erreurs d'exécution de la requête
    echo "Erreur lors de l'exécution de la requête SQL.";
}

$user_id = us_id;
// Requête SQL pour vérifier s'il y a des notifications non lues pour l'utilisateur connecté
$sql = "SELECT * FROM pl_notifications WHERE user_id = ? AND unread = 0";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

// Fermer la connexion à la base de données
//$db->close();

// Fonction d'ajout d'un article au panier 
function addToCart($item) {
    if (isset($_SESSION['login'])) {
        // Si l'utilisateur est connecté, ajoutez l'article à la session
        $_SESSION['addtocart'][] = $item;
    } else {
        // Si l'utilisateur n'est pas connecté, ajoutez l'article aux cookies
        $cart = isset($_COOKIE['addtocart']) ? json_decode($_COOKIE['addtocart'], true) : [];
        $cart[] = $item;
        setcookie('addtocart', json_encode($cart), time() + (86400 * 30), "/");
    }
}

// Nettoyer le panier
function clearCart() {
    if (isset($_SESSION['login'])) {
        // Si l'utilisateur est connecté, videz la session du panier
        unset($_SESSION['addtocart']);
    } else {
        // Si l'utilisateur n'est pas connecté, supprimez les cookies du panier
        setcookie('addtocart', '', time() - 3600, "/");
    }
}

// Fonction pour compter le nombre d'articles dans le panier
function countCart() {
    if (isset($_SESSION['login'])) {
        // Si l'utilisateur est connecté, comptez le nombre d'articles dans la session
        return isset($_SESSION['addtocart']) ? count($_SESSION['addtocart']) : 0;
    } else {
        // Si l'utilisateur n'est pas connecté, comptez le nombre d'articles dans les cookies
        return isset($_COOKIE['addtocart']) ? count(json_decode($_COOKIE['addtocart'], true)) : 0;
    }
}


?>

<?php if(!us_level && !us_id): ?>

	<style>

/* Conteneur pour l'icône de notification */
.notification-dialog {
	position: relative;
    margin-top: 12px; /* Ajustez la marge supérieure selon vos besoins */
	margin-right: 22px;
	cursor: pointer;
	
}

/* Style pour l'icône de notification */
#notification-icon {
    position: relative;
	cursor: pointer;
	align-items: center;
	left: 5px;
    font-size: 14px;
}

</style>
<?php endif; ?>

<style>

/* Conteneur pour l'icône de notification */
.notification-dialog {
	position: relative;
    margin-top: 12px; /* Ajustez la marge supérieure selon vos besoins */
	margin-right: 22px;
	cursor: pointer;
	
}

/* Style pour l'icône de notification */

/* Style pour le compteur numérique */
.counter {
    position: absolute;
    top: -4px;
    right: -9px;
    background-color: #ff0000; /* Couleur de fond */
    color: #ffffff; /* Couleur du texte */
    font-size: 10px;
    font-weight: bold;
    width: 17px;
    height: 16px;
    border-radius: 50%;
    text-align: center;
    line-height: 17px;
}

/***Style boite de notification ****/

/* Style pour la boîte de dialogue des notifications */
#notifications-dialog {
    position: absolute;
    top: 50px; /* Ajustez la position verticale selon vos besoins */
    right: 15px; /* Ajustez la position horizontale selon vos besoins */
    width: 283px; /* Ajustez la largeur selon vos besoins */
    background-color: #fff;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    display: none; /* Initialement caché */
    overflow-y: auto; /* Ajouter une barre de défilement si nécessaire */
}

/* Style pour la liste des notifications */
#notifications-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
}

/* Style pour chaque notification dans la liste */
#notifications-list li {
    padding: 10px;
    border-bottom: 1px solid #eee;
}

#notifications-list li:hover {
    background-color: #ff9f0e; /* Couleur de fond au survol */
    color: #ffffff;
    cursor: pointer; /* Afficher le curseur pointer */
    border-radius: 5px;
}
/* Style pour la dernière notification sans bordure inférieure */
#notifications-list li:last-child {
    border-bottom: none;
}


</style>

<div id="full-page-container">
<div class="pt-wrapper">
	<div class="pt-header">
		<div class="pt-header-top">
			<?=(page != "index" ?'<div class="over"><span class="pt-bg"></span></div>':"")?>

			<div class="container">
				<div class="pt-logo"><a href="<?=path?>">
				<?php
        // Chemin absolu vers le répertoire racine
        $basePath = '/yum';

        // Chemin relatif vers l'image du logo
        $logoPath = $basePath . '/img/yum-logo.png';

        // Vérifier si le script est dans le répertoire racine
        if ($_SERVER['PHP_SELF'] === $basePath . '/index.php') {
            // Si dans le répertoire racine, afficher le logo depuis le répertoire courant
            echo '<img src="' . $logoPath . '" alt="YUM">';
        } else {
            // Sinon, afficher le logo depuis le répertoire parent
            echo '<img src="' . dirname($logoPath) . '../' . basename($logoPath) . '" alt="YUM">';
        }
        ?>
			</a>
			</div>
				<div class="pt-menu">
					<ul>
						<li><a href="<?=path?>"><?=$lang['header']['home']?></a></li>
						<li><a href="<?=path?>/cuisines.php"><?=$lang['header']['explore']?></a></li>
						<?php if(us_level == 1 || us_level == 6): ?>
						<li><a href="<?=path?>/restaurants.php"><?=$lang['header']['restaurants']?></a></li>
						<?php endif; ?>
						<li><a href="<?=path?>/pages.php?id=3&t=about"><?=$lang['header']['about']?></a></li>
						<li><a href="<?=path?>/pages.php?id=4&t=contact"><?=$lang['header']['contact']?></a></li>
						<li><a href="<?=path?>/plans.php"><?=$lang['header']['plans']?></a></li>
						<li class="pt-mobile-menu">
							<a href="#"><i class="icon-menu icons"></i></a>
							<ul class="pt-drop">
								<li><a href="<?=path?>"><?=$lang['header']['home']?></a></li>
								<li><a href="<?=path?>/cuisines.php"><?=$lang['header']['explore']?></a></li>
								<?php if(us_level == 1 || us_level == 6): ?>
								<li><a href="<?=path?>/restaurants.php"><?=$lang['header']['restaurants']?></a></li>
								<?php endif; ?>
								<li><a href="<?=path?>/pages.php?id=3&t=about"><?=$lang['header']['about']?></a></li>
								<li><a href="<?=path?>/pages.php?id=4&t=contact"><?=$lang['header']['contact']?></a></li>
								<li><a href="<?=path?>/plans.php"><?=$lang['header']['plans']?></a></li>
							</ul>
						</li>
						<li class="pt-cart">
							<a href="<?=path?>/cart.php">
								<i class="icon-basket icons"></i>
								<b><?=(isset($_COOKIE['addtocart'])?count(json_decode($_COOKIE['addtocart'],true), 1)-count(json_decode($_COOKIE['addtocart'],true)):'0')?></b>
							</a>
						</li>
						<!-- Icône de notification -->
                        <li class="pt-notification">
					    	
							<!-- Boîte de dialogue des notifications -->
    <div class="notification-dialog" id="notification-dialog">
        <!-- Compteur numérique -->
        <?php if(us_id): ?>
			<span id="notification-counter" class="counter">0</span>
        <?php endif; ?>
        <!-- Icône de notification -->
        <i class="fas fa-bell" id="notification-icon"></i>
        
        <!-- Boîte de dialogue des notifications -->
        <div id="notifications-dialog" style="display: none;">
            <ul id="notifications-list">
            <!--?php if ($row['unread'] == 0): ?>
               <li>No notifications present yet</li-->
            <!--?php endif; ?-->
                <!-- Les notifications seront chargées ici via AJAX -->
            </ul>
        </div>
    </div>
						</li>

						<?php if(us_level): ?> 
							<li class="pt-img">
								<div class="pt-thumb"><img src="<?=path?>/<?=us_photo?>" onerror="this.src='<?=nophoto?>'"></div>
							</li>
							<li class="pt-author">
								<?php
								$head_orders = db_rows("orders WHERE status = 0 and user = '".us_id."'");
								if($head_orders) echo "<b>".$head_orders."</b>";
								?>
								<span class="pt-showmenudetails"><?=us_username?> <i class="fas fa-caret-down"></i></span>
								<ul class="pt-drop">
									<?php if(us_level == 6): ?>
									<li><a href="<?=path?>/dashboard.php?user_id=<?= us_id ?>"><i class="icons icon-speedometer"></i> <?=$lang['header']['dashboard']?></a></li>
									<?php elseif(us_level == 4): // Si l'utilisateur est un traiteur ?>
								    <li><a href="<?=path?>/restau_dashboard.php?user_id=<?= us_id ?>&restau_id=<?= $restaurantId ?>&restau_name=<?=$restaurantName ?>"><i class="icons icon-speedometer"></i> <?=$lang['header']['dashboard']?></a></li>
									<?php elseif(us_level == 2): // Si l'utilisateur est un livreur ?>
								    <li><a href="<?=path?>/deliverer_dashboard.php?user_id=<?= us_id ?>"><i class="icons icon-speedometer"></i> <?=$lang['header']['dashboard']?></a></li>
                                    <?php endif; ?>
									<?php if(us_level == 1 || us_level == 6): ?>
									<li><a href="<?=path?>/myorders.php"><i class="icons icon-wallet"></i> <?=$lang['header']['my_orders']?></a></li>
									<?php endif; ?>
									<?php if(us_plan && (us_level == 6 || us_level == 4)): ?>
									<li><a href="<?=path?>/restaurant.php"><i class="fas fa-store"></i> <?=$lang['header']['your_restaurant']?></a></li>
									<?php endif; ?>
									<li><a href="#testimonialModal" data-toggle="modal"><i class="far fa-comment"></i> <?=$lang['header']['testimonial']?></a></li>
									<li><a href="#passwordModal" data-toggle="modal"><i class="icons icon-lock-open"></i> <?=$lang['header']['change_password']?></a></li>
									<li><a href="<?=path?>/userdetails.php"><i class="fas fa-pencil-alt"></i> <?=$lang['header']['edit_details']?></a></li>
									<li><a href="<?=path?>/logout.php" onclick="logoutAndShowNotification(event)"><i class="icons icon-power"></i> <?=$lang['header']['logout']?></a></li>
								</ul>
							</li>
						<?php else: ?>
							<li class="pt-login"><a data-toggle="modal" href="#loginModal"><i class="icon-user icons"></i> <?=$lang['header']['login']?></a></li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div><!-- End header top -->

		<?php if(page == "index"): ?>
		<div class="pt-header-content">
			<div class="container">
				<div class="pt-body">
					<h1><?=str_replace('[br]', '<br />', $lang['header']['title'])?></h1>
					<p>
						<?=$lang['header']['subtitle']?>
					</p>
					<a href="<?=path?>/cuisines.php"><?=$lang['header']['btn']?> <i class="fas fa-long-arrow-alt-right"></i></a>
					<div class="pt-info">
						<div>
							<span><i class="icons icon-clock"></i></span>
							<h3><?=$lang['header']['today']?></h3>
							<p><?=$lang['header']['working_hours']?></p>
						</div>
						<div>
							<span><i class="icons icon-phone"></i></span>
							<h3><?=$lang['header']['phone']?></h3>
							<p><?=$lang['header']['call']?></p>
						</div>
					</div>
				</div>
				<div class="pt-thumb">
					<span class="pt-bg"></span>
					<img src="<?=path?>/img/burger.png" onerror="this.src='<?=noimage?>'" />
				</div>
			</div>
		</div><!-- End header Content -->
		<?php endif; ?>
	</div>
	<!-- End header -->

<!-------------------- Script AJAX Notifications ---------------------------------------->

<script>

// Fonction pour charger les notifications et mettre à jour le compteur

//////////////////////////////////////////////////////////////////////////////

// Fonction pour charger les notifications et mettre à jour le compteur
function loadNotificationsAndUpdateCounter() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'load_notifications.php', true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            var notifications = JSON.parse(xhr.responseText);
            var unreadCount = notifications.filter(function(notification) {
                return notification.unread === 1; // Filtrer les notifications non lues
            }).length;
            updateNotificationCounter(unreadCount); // Mettre à jour le compteur
            displayNotifications(notifications); // Afficher les notifications dans la boîte de dialogue
        }
    };
    xhr.send();
}

// Fonction pour afficher les notifications dans la boîte de dialogue
function displayNotifications(notifications) {
    var notificationsList = document.getElementById('notifications-list');
    //notificationsList.innerHTML = ''; // Effacer les anciennes notifications
    
    /*if (notifications.length === 0) {
        var noNotificationMessage = document.createElement('li');
        noNotificationMessage.textContent = "No notifications present yet.";
        notificationsList.appendChild(noNotificationMessage);
    } else {*/
        notifications.forEach(function(notification) {
            var li = document.createElement('li');
            li.textContent = notification.message;
            notificationsList.appendChild(li);
        });
        
  //}
}


// Fonction pour mettre à jour le compteur de notifications
function updateNotificationCounter(count) {
    var counterElement = document.getElementById('notification-counter');
    if (counterElement) {
        counterElement.textContent = count; // Mettre à jour le contenu de la balise <span>
    }
}

// Fonction pour marquer les notifications comme lues
function markNotificationsAsRead() {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'mark_notifications_as_read.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
        if (xhr.status === 200) {
            loadNotificationsAndUpdateCounter(); // Recharger les notifications après les avoir marquées comme lues
        }
    };
    xhr.send();
}

// Événement pour afficher les notifications lors du clic sur l'icône de notification
// Afficher la boîte de dialogue des notifications lors du clic sur l'icône de notification
var notificationIcon = document.getElementById('notification-dialog');
var notificationsDialog = document.getElementById('notifications-dialog');

notificationIcon.addEventListener('click', function(event) {
    event.stopPropagation(); // Empêcher la propagation de l'événement de clic au document
    toggleNotificationsDialog(); // Fonction pour afficher ou masquer la boîte de dialogue
});

// Cacher la boîte de dialogue des notifications lors du clic en dehors de celle-ci
document.addEventListener('click', function(event) {
    var isClickInside = notificationsDialog.contains(event.target);
    var notificationsList = document.getElementById('notifications-list');
    if (!isClickInside) {
        notificationsDialog.style.display = 'none';
        notificationsList.innerHTML = ''; // Effacer les anciennes notifications
    } else {
        notificationsDialog.style.display = 'block';
    }
});

// Fonction pour afficher ou masquer la boîte de dialogue des notifications
function toggleNotificationsDialog() {
    if (notificationsDialog.style.display === 'none') {
        notificationsDialog.style.display = 'block';
        markNotificationsAsRead();
    } else {
        notificationsDialog.style.display = 'none';
    }
}

// Charger les notifications au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    loadNotificationsAndUpdateCounter();
});

///////////////////// Fonction pour afficher une notification de succès après déconnexion

function logoutAndShowNotification(event) {
    event.preventDefault(); // Empêche le lien de se comporter normalement (navigation)

    // Effectuer le processus de déconnexion ici...

    // Effectuer une requête AJAX pour vérifier si la déconnexion a été réussie
    // et afficher la notification uniquement si c'est le cas
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '<?=path?>/logout.php');
    xhr.onload = function() {
        if (xhr.status === 200) {
            showSuccessNotification('Logout successful !');
            window.location.href = '<?=path?>/logout.php'; // Rediriger vers la page de déconnexion
        } else {
            console.log('Erreur lors de la déconnexion');
        }
    };
    xhr.send();
}

function showSuccessNotification(message) {
    // Vérifiez si le navigateur prend en charge les notifications
    if ('Notification' in window) {
        // Vérifiez si les notifications sont autorisées
        if (Notification.permission === 'granted') {
            // Créez une notification
            new Notification('Success', { body: message });
        } else if (Notification.permission !== 'denied') {
            // Demandez la permission à l'utilisateur pour afficher les notifications
            Notification.requestPermission().then(function(permission) {
                if (permission === 'granted') {
                    // Créez une notification si la permission est accordée
                    new Notification('Success', { body: message });
                }
            });
        }
    }
}

</script>
