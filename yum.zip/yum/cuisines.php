<?php

include __DIR__."/header.php";

?>

<div class="pt-breadcrumb-p">
	<div class="container">
		<h3><?=$lang['cuisines']['title']?></h3>
		<p><?=$lang['cuisines']['desc']?></p>
	</div>
</div>

<div class="container">

<?php if ($id): ?>

	<div class="row">
		<?php
		$sql = $db->query("SELECT pl_items.*, pl_restaurants.name AS restaurant_name, pl_restaurants.id AS restau_id FROM pl_items JOIN pl_restaurants ON pl_items.restaurant = pl_restaurants.id WHERE pl_items.cuisine = '{$id}' ORDER BY pl_items.id DESC LIMIT {$startpoint} , {$limit}");
		if($sql->num_rows):
		while ($rs = $sql->fetch_assoc()):
		?>
		<div class="col-4">
			<div class="pt-post">
				<div class="pt-thumb"><img src="<?=path.'/'.$rs['image']?>" onerror="this.src='<?=noimage?>'"></div>
				<div class="pt-details">
					<div class="pt-option">
						<?php if (db_get("restaurants", "neworders", $rs['restaurant'])): ?>
						<?php echo("Test") ?>
						<?php else: ?>
							<a data-toggle="modal" href="#addtocartModal" data-id="<?=$rs['id']?>" class="pt-addtobasket pt-addtocart tips"><i class="icons icon-basket"></i><b><?=$lang['home']['addtocart']?></b></a>
						<?php endif; ?>
					</div>
					<a href="#" class="pt-price"><?=$rs['selling_price'].dollar_sign?></a>
					<div class="pt-title"><h1><a href="#"><?=$rs['name']?></a></h1></div>
					<div class="pt-info">
						<span><i class="icons icon-clock"></i> <?=($rs['delivery_time'] ? $rs['delivery_time'] : '--')?></span>
						<span class="pt-stars"><?php echo fh_stars($rs['id'], "item") ?></span>
					</div>
					<div class="pt-tags">
						<a href="<?=path?>/cuisines.php?id=<?=$rs['cuisine']?>&t=<?=fh_seoURL(db_get("cuisines", "name", $rs['cuisine']))?>"><?=db_get("cuisines", "name", $rs['cuisine'])?></a>
						<a href="<?=path?>/restaurants.php?id=<?=$rs['restau_id']?>&t=<?=fh_seoURL($rs['name'])?>" style="background-color: #fff; color: #ff9f0e; margin-left: 0; border-radius: 10px; align-content: center;"><i class="fas fa-location-arrow" style="color:orange;"></i>  <?= $rs['restaurant_name'] ?> </a>
					</div>
				</div>
			</div>
		</div>
		<?php endwhile; ?>
		<?php else: ?>
		<div class="text-center"><?=$lang['alerts']['no-data']?></div>
		<?php endif; ?>
		<?php echo fh_pagination("items  WHERE cuisine = '{$id}'",$limit, path."/cuisines.php?id={$id}&") ?>

	</div><!-- End Row -->

<?php else: ?>

	<div class="row">
		<?php
		$sql = $db->query("SELECT * FROM ".prefix."cuisines ORDER BY id DESC LIMIT {$startpoint} , {$limit}");
		if($sql->num_rows):
		while($rs = $sql->fetch_assoc()):
		?>
		<div class="col-3">
			<div class="pt-item">
				<a href="<?=path?>/cuisines.php?id=<?=$rs['id']?>&t=<?=fh_seoURL($rs['name'])?>">
				<div class="pt-thumb"><img src="<?=path?>/<?=$rs['image']?>" alt="<?=$rs['name']?>" onerror="this.src='<?=noimage?>'"></div>
				<div class="pt-title"><h3><?=$rs['name']?></h3></div>
				</a>
			</div>
		</div>
		<?php endwhile; ?>
		<?php else: ?>
			<div class="text-center"><?=$lang['alerts']['no-data']?></div>
		<?php endif; ?>
		<?php $sql->close(); ?>
	</div>
	<?php echo fh_pagination("cuisines",$limit, path."/cuisines.php?") ?>

<?php endif; ?>

</div>


<?php
include __DIR__."/footer.php";
