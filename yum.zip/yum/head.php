<?php

include __DIR__."/configs.php";

hash_hmac(
	'sha256', // hash function
	$user->id, // IMPORTANT: a UUID to identify your user
	'kDN_ti3jfOyQm6yc6euakgbOjFtfGoxqAH9z1xGQ' // IMPORTANT: your web Identity Verification secret key - keep it safe!
  );

?>

<!DOCTYPE html>
<html lang="<?=$lang['lang']?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?=fh_title()?></title>

	<meta name="title" content="<?=fh_title()?>">
	<meta name="description" content="<?=site_description?>">
	<meta name="keywords" content="<?=site_keywords?>">

	<!-- Open Graph / Facebook -->
	<meta property="og:type" content="website">
	<meta property="og:url" content="<?=site_url?>">
	<meta property="og:title" content="<?=fh_title()?>">
	<meta property="og:description" content="<?=site_description?>">
	<meta property="og:image" content="<?=site_url?>">

	<!-- Twitter -->
	<meta property="twitter:card" content="summary_large_image">
	<meta property="twitter:url" content="<?=site_url?>">
	<meta property="twitter:title" content="<?=fh_title()?>">
	<meta property="twitter:description" content="<?=site_description?>">
	<meta property="twitter:image" content="<?=site_url?>">

	<!-- Favicon -->
	<link rel="shortcut icon" href="<?=path?>/<?=site_favicon?>" type="image/png" />

	<!-- Google Fonts -->
	<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,900%7CGentium+Basic:400italic%7COpen+Sans:400italic,700italic,400,300,700">

	<!-- Plugins -->
	<link rel="stylesheet" href="<?=path?>/css/all.min.css">
	<link rel="stylesheet" href="<?=path?>/css/tt.css">
	<link rel="stylesheet" href="<?=path?>/css/simple-line-icons.css">
	<link rel="stylesheet" href="<?=path?>/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?=path?>/js/minified/themes/default.min.css" />
	<link rel="stylesheet" href="<?=path?>/css/jquery-confirm.min.css">
	<link rel="stylesheet" href="<?=path?>/css/lightbox.css" />
	<link rel="stylesheet" href="<?=path?>/css//bootstrap-select.min.css">
	<link rel="stylesheet" href="<?=path?>/css/flag-icon.min.css">
	<link rel="stylesheet" href="<?=path?>/js/file_upload/fileinput.css" />
	<link rel="stylesheet" href="<?=path?>/css/owl.carousel.min.css" />
	<link rel="stylesheet" href="<?=path?>/css/scrolls.css" />

	<link rel="stylesheet" href="<?= path ?>/css/<?= (page != "dashboard" && page != "restau_dashboard" && page != "deliverer_dashboard") ? 'style' : 'cpanel' ?>.css">

	<!------ Chat live ---------->

<script>
  window.intercomSettings = {
    api_base: "https://api-iam.intercom.io",
    app_id: "b80280bh",
    user_id: <?php echo json_encode($current_user->id) ?>, // WICHTIG: Ersetzen Sie „user.id“ durch die Variable, mit der Sie die ID des Benutzers erfassen.
    name: <?php echo json_encode($current_user->name) ?>, // WICHTIG: Ersetzen Sie „user.name“ durch die Variable, mit der Sie den Namen des Benutzers erfassen.
    email: <?php echo json_encode($current_user->email) ?>, // WICHTIG: Ersetzen Sie „user.email“ durch die Variable, mit der Sie die E-Mail-Adresse des Benutzers erfassen.
    created_at: "<?php echo strtotime($current_user->created_at) ?>", // WICHTIG: Ersetzen Sie "user.createdAt" durch die Variable, mit der Sie das Anmeldedatum des Benutzers erfassen.
  };
</script>


<script>
  // Wir haben Ihre App-ID in der Widget-URL vorausgefüllt: 'https://widget.intercom.io/widget/b80280bh'
  (function(){var w=window;var ic=w.Intercom;if(typeof ic==="function"){ic('reattach_activator');ic('update',w.intercomSettings);}else{var d=document;var i=function(){i.c(arguments);};i.q=[];i.c=function(args){i.q.push(args);};w.Intercom=i;var l=function(){var s=d.createElement('script');s.type='text/javascript';s.async=true;s.src='https://widget.intercom.io/widget/b80280bh';var x=d.getElementsByTagName('script')[0];x.parentNode.insertBefore(s,x);};if(document.readyState==='complete'){l();}else if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();
</script>

</head>
<body<?=(page?' class="pt-'.page.'page"':'')?>>
