<?php

if( $_SERVER['REQUEST_METHOD'] === 'POST' && us_level ){

	$p_title   = isset($_POST['title']) ? sc_sec($_POST['title'])     : '';
	$p_content = isset($_POST['content']) ? sc_sec($_POST['content']) : '';
	$p_review  = isset($_POST['rating']) ? (int)($_POST['rating'])    : 0;
	$p_id      = isset($_POST['id']) ? (int)($_POST['id'])            : 0;

	if(empty($p_title) || !$p_id || !$p_review){
		$alert = ["alert" => fh_alerts("All fields marked with * are required!"), "type" => "danger"];
	} elseif(!db_rows("orders WHERE item = '{$p_id}' && author = '".us_id."'")){
		$alert = ["alert" => fh_alerts("You cant add review to this item!"), "type" => "danger"];
	} elseif(db_rows("reviews WHERE item = '{$p_id}' && author = '".us_id."'")){
		$alert = ["alert" => fh_alerts("You already add a review to this item!"), "type" => "danger"];
	} else {

		$p_restaurant = db_get("items", "restaurant", $p_id);

		$data = [
			"title"      => $p_title,
			"content"    => $p_content,
			"stars"      => $p_review,
			"item"       => $p_id,
			"user"       => db_get("items", "author", $p_id),
			"restaurant" => $p_restaurant,
			"author"     => us_id,
			"created_at" => time()
		];

		db_insert('reviews', $data);

        if (isset($data)) {
			// Vérifier que us_id est défini
			$us_id = us_id;
			if (!isset($us_id)) {
				// Gérer le cas où us_id n'est pas défini
				echo "User ID is not set.";
				exit; // Quitter le script
			}
		
			$sql ="SELECT pl_restaurants.name AS restaurant_name
			        FROM pl_reviews 
			        JOIN pl_restaurants ON pl_reviews.restaurant = pl_restaurants.id 
			        JOIN pl_users ON pl_reviews.user = pl_users.id
			        WHERE pl_reviews.author = $us_id
					ORDER BY FROM_UNIXTIME(pl_reviews.created_at) DESC
					LIMIT 1";
			$rs = $db->query($sql);
			if ($rs) {
				// Vérifier si la requête a renvoyé des résultats
				if ($rs->num_rows > 0) {
					$row = $rs->fetch_assoc();
					$restaurant_name = $row['restaurant_name'];
					$message = "Thank you for your review on $restaurant_name!";
					
					// Insérer la notification dans la base de données
					$sql_insert = "INSERT INTO pl_notifications (user_id, message) VALUES (?, ?)";
					$stmt_insert = $db->prepare($sql_insert);
					$stmt_insert->bind_param("is", $us_id, $message);
					$stmt_insert->execute();
					$stmt_insert->close();
				} else {
					// Gérer le cas où la requête n'a renvoyé aucun résultat
					echo "No restaurant found for the user.";
				}
			} else {
				// Gérer le cas où la requête a échoué
				echo "Error executing SQL query.";
			}
		} else {
			// Gérer le cas où $data n'est pas défini
			echo "Data is not set.";
		}
		
		db_update('restaurants', ['rating' => fh_stars($p_restaurant, 'restaurant', false)], $p_restaurant);

		$alert = ["alert" => fh_alerts("Success! all done!!", "success"), "type" => "success"];

	}

	echo json_encode($alert);
}
