<?php
include __DIR__."/configs.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifier si l'ID du commentaire est fourni dans la requête POST
    if (isset($_POST['id'])) {
      $reviewId = $_POST['id'];
  
      // Exécuter la requête de suppression
      $sql = "DELETE FROM pl_reviews WHERE id = $reviewId";
  
      if ($db->query($sql) === TRUE) {
        // La suppression a réussi
        $response = array('success' => true, 'message' => 'Article supprimé avec succès.');
        // Recharger la page après la suppression
        echo '<script>window.location.reload();</script>';
        echo '<script>window.location.href = window.location.href;</script>';
      } else {
        // La suppression a échoué
        $response = array('success' => false, 'message' => 'Erreur lors de la suppression de l\'avis : ' . $db->error);
      }
  
      // Fermer la connexion à la base de données
      $db->close();
  
      // Renvoyer la réponse au format JSON
      header('Content-Type: application/json');
      echo json_encode($response);
      
      // Terminer l'exécution du script
      exit();
    }
  }
  
  // Si l'ID de l'article n'est pas fourni ou si la requête n'est pas une requête POST
  // Renvoyer une réponse d'erreur
  $response = array('success' => false, 'message' => 'ID de l\'avis non fourni ou requête invalide.');
  
  // Renvoyer la réponse au format JSON
  header('Content-Type: application/json');
  echo json_encode($response);

?>