<?php

include __DIR__."/header.php";

// Vérifier si l'utilisateur est connecté
if (isset($_SESSION['login'])) {
    // Charger le panier de l'utilisateur à partir de la session ou initialiser un nouveau panier
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    } else {
        $cart = array();
    }
} 
?>

<style>
	.text-sm-right a:hover{
        color: white;
	}
	#btn-cpromo{
		position: relative;
		display: flex;
		font-size: 15px;
		color: #fff;
		cursor: pointer;
		/*margin-top: 5px;*/
		padding-left: 8px;
		align-items: center;

	}

</style>

<div class="pt-breadcrumb-p">
	<div class="container">
		<h3><?=$lang['cart']['title']?></h3>
		<p><?=$lang['cart']['desc']?></p>
	</div>
</div>

<div class="container">

	<div class="row">
		<div class="col-8">
		<div class="pt-cart-body">
			<?php
			if(isset($_COOKIE['addtocart'])):
			foreach(json_decode($_COOKIE['addtocart'], true) as $cart_id => $carts):
				foreach($carts as $it_id => $cart):
					if(!empty(str_replace('[]','', $cart))):
					$cart = json_decode($cart, true);
					$rs = db_rs("items WHERE id = '{$cart_id}'");

					$item_size = isset($cart['item_size']) ? db_unserialize([$rs['sizes'], $cart['item_size']]) : '';
			?>
			<div class="pt-cart-body">
				<div class="media">
					<div class="media-left"><div class="pt-thumb"><img src="<?=path?>/<?=$rs['image']?>" alt="<?=$rs['name']?>" onerror="this.src='<?=noimage?>'"></div></div>
					<div class="media-body">
						<div class="pt-dtable">
							<div class="pt-vmiddle">
								<div class="pt-title"><h3><a href="#"><?=$rs['name']?></a></h3></div>
								<div class="pt-extra"><small><?=str_replace("+", " ", $cart['item_note'])?></small></div>
								<?php if ($rs['delivery_price']): ?>
								<div class="d-none pt-deliveryprice"><?=$rs['delivery_price']?></div>
								<?php endif; ?>
								<div class="pt-extra">
									<?php if($item_size): ?>
									<strong>Size: <a><?=$item_size['name']?></a></strong> -
									<?php endif; ?>
									<strong>Price: <a class="checked"><?=($item_size ? $item_size['price'] : $rs['selling_price']).dollar_sign?></a></strong>
								</div>
								<div class="pt-extra">
									<?php
									if($cart['item_extra']):
									foreach($cart['item_extra'] as $k => $extra):
										$extra = db_unserialize([$rs['extra'], $extra]);
									?>
										<span>
											<?=$extra['name']?> <b class="pt-extraprice"><?=$extra['price']?></b>
											<i class="fas fa-times pt-removeexratoitem" data-price="<?=$extra['price']?>" data-id="<?=$k?>" data-iid="<?=$it_id?>" data-iiid="<?=$cart_id?>"></i>
										</span>
									<?php
									endforeach;
									endif;
									?>
								</div>
								<div class="pt-options">
									<a href="#" class="pt-removefromcart" data-iid="<?=$it_id?>" data-iiid="<?=$cart_id?>"><i class="fas fa-trash"></i></a>
									<div class="pt-quantity">
										<i class="fas fa-minus pt-minus" data-i="<?=$it_id?>" data-a="<?=$cart_id?>" style="cursor: pointer"></i>
										<input type="text" name="item_quantity" value="<?=$cart['item_quantities']?>" disabled>
										<i class="fas fa-plus pt-plus" data-i="<?=$it_id?>" data-a="<?=$cart_id?>" style="cursor: pointer"></i>
									</div>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endif; ?>
			<?php endforeach; ?>
			<?php endforeach; ?>
			<?php else: ?>
				<div class="text-center"><?=$lang['alerts']['no-data']?></div>  <!------ Your Shopping Cart is Empty --------------->
			<?php endif; ?>
		</div>
		</div>
		<div class="col-4">
			<div class="pt-cart-body">

				<div id="checkout">

		      <form id="payment-form" method="POST" action="stripe.php" <?php if(!us_level): ?> style="bottom: 50px; right: 20px; z-index: 1000; max-height: 940px;" <?php endif; ?>>
						<h2><?=$lang['cart']['order_summary']?></h2>
						<div class="fieldset mb-4">
							<p class="mt-2"><span><?=$lang['cart']['subtotal']?></span><b class="float-right pt-totalprice">0.00 <?=dollar_sign?></b></p>
							<p><span><?=$lang['cart']['shipping_fees']?></span><b class="float-right pt-deliverytotalprice">0.00 <?=dollar_sign?></b></p>
							<hr />
							<p><span><?=$lang['cart']['total']?></span><b class="float-right pt-alltotalprice">0.00 <?=dollar_sign?></b></p>
						</div>

	          <h2><?=$lang['cart']['billing']?></h2>
						<div class="fieldset">
	            <label class="label">
	              <span><?=$lang['cart']['name']?></span>
	              <input name="name" value="<?=us_firstname?> <?=us_lastname?>" class="field" placeholder="Cedric RAMSEY" required>
	            </label>
	            <label class="label">
	              <span><?=$lang['cart']['email']?></span>
	              <input name="email" value="<?=us_email?>" type="email" class="field" placeholder="cedric@example.com" required>
	            </label>
	            <label class="label">
	              <span><?=$lang['cart']['phone']?></span>
	              <input name="phone" value="<?=us_phone?>" type="text" class="field phone" placeholder="0000-000-000"required>
	            </label>
	            <label class="label">
	              <span><?=$lang['cart']['address']?></span>
	              <input name="address" value="<?=us_address?>" class="field" placeholder="31 rue Paul Meurice"required>
	            </label>
	            <label class="label">
	              <span><?=$lang['cart']['city']?></span>
	              <input name="city" value="<?=us_city?>" class="field" placeholder="Paris"required>
	            </label>
	            <label class="state label">
	              <span><?=$lang['cart']['state']?></span>
	              <input name="state" value="<?=us_state?>" class="field" placeholder="Île-de-France"required>
	            </label>
	            <label class="zip label">
	              <span><?=$lang['cart']['zip']?></span>
	              <input name="postal_code" class="field" placeholder="75020"required>
	            </label>
	            <label class="select label">
	              <span><?=$lang['cart']['country']?></span>
	              <div id="country" class="field US">
									<select class="selectpicker" data-live-search="true" data-width="100%" name="country" title="<?=$lang['cart']['country']?>"required>
										<?php foreach($countries as $k => $c): ?>
											<option data-tokens="<?=$k?> <?=$c?>" value="<?=$k?>"<?=(!empty(us_country) && us_country == $k ? "selected" : ($k == 'FR' ? ' selected' : ''))?>><?=$c?></option>
										<?php endforeach; ?>
									</select>
	              </div>
	            </label>
							<label class="select label">
	              <span><?=$lang['cart']['gender']?></span>
								<div id="gender" class="field US">
								<select name="gender" class="selectpicker" data-width="100%" title="<?=$lang['cart']['gender_s']?>"required>
									<option value="1"<?=(us_gender == 1 ? "selected" : "")?>><?=$lang['cart']['male']?></option>
									<option value="2"<?=(us_gender == 2 ? "selected" : "")?>><?=$lang['cart']['female']?></option>
								</select>
								</div>
							</label>
						</div>
						
						<!-------------------Promo code-------------------->

						<?php if(us_level): ?>

 <div class="text-center mt-2" id="showPromoInput" style="font-size: 10px;">
    <a href="#" class="text-sm-right" style="color: gray" id="promoLink">
        Got a promo code?
    </a>
 </div>
						<div class="fieldset mt-4" style="margin-bottom: 20px">
							<label>
								<span><?=$lang['cart']['card']?></span>
								<div id="card-element" class="field"></div>
								<div id="card-errors" role="alert"></div>
								<input type="hidden" name="amount" class="hidamount" value="" />
							</label>
						</div>
						
						<button class="payment-button" type="submit"><?=$lang['cart']['pay']?></button>
					    <?php endif; ?>
						
						<?php if(!us_level): ?>
						<a data-toggle="modal" href="#loginModal">
							
						<button class="payment-button">Pay Cash</button>
						</a>
						<?php endif; ?>
      		</form>
			  
					<form id="sendpaypalitem">

			      <input type="hidden" name="item_number" value="<?=time()?>" />
						<?php if(us_level): ?>
						<button class="paypal-button" type="submit" name="button" style="bottom: 5px">
				    		<span class="paypal-button-title">Pay with </span>
							<span class="paypal-logo"><i>Pay</i><i>Pal</i></span>
						</button>

						<!--label for="cash-payment">
                        <input type="checkbox" id="cash-payment" name="payment_method" value="cash">
                        Cash Payment
                       </label--> 
						
						<?php else: ?>
							<a data-toggle="modal" href="#loginModal">
							<div id="paypal-container" style="width: 100%"></div>
							    <!--span class="paypal-button-title">Pay with </span-->
								<!--div class="paypal-logo" id="paypal-container"></div-->
							</a>
							<script src="https://www.paypal.com/sdk/js?client-id=AaDy1DSrD84wZ4Mxc-hxiPrMHjU55SLeOQwPkZI5mh1thOd3kIi7Zm3naqHCRgMAB-2PlRRIGgbiwcRB"></script>
						<script>
                             paypal.Buttons({
                            
                           onClick: function() {
                           redirectToLoginModal();
                        }
                        }).render("#paypal-container");

                        function redirectToLoginModal() {
                        // Redirection vers la page loginModal
                         window.location.href = "#loginModal";
                        }
                        </script>
						<?php endif; ?>
			    </form>
				<form id="frmPromo" method="post" class="codepromo" style="display: none">
                <input type="hidden" name="token" value="fd233a0a9aba956afff9e411372a485d60a96c21" />
   <div class="form-group input-group input-group-sm prepend-icon" style="margin-top: 5px">
	   <label for="inputPromotionCode" class="field-icon">
		   <i class="fas fa-ticket-alt" style="color: gray"></i>
	   </label>
	   <input type="text" name="couponCode" id="couponCode" class="field form-control" placeholder="Promotion code" style="border-top-left-radius: 3px; border-bottom-left-radius: 4px;" required="required">
	   <div class="input-group-append" style="background-color: #ff9f0e; color: #fff; width: 30px; border-top-right-radius: 5px; border-bottom-right-radius: 5px;">
		  <i class="fas fa-check" id="btn-cpromo" name="validatepromo" title="Validate Code"></i>
	   </div>
   </div>
</form>

    		</div>

			</div>
		</div>
	</div>

</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    document.getElementById('promoLink').addEventListener('click', function(event) {
        event.preventDefault(); // Empêcher le lien de suivre son URL
        document.getElementById('showPromoInput').style.display = 'none';
        document.getElementById('frmPromo').style.display = 'block';
        document.getElementById('couponCode').focus();
    });

	$(document).ready(function() {
    $('#btn-cpromo').click(function(event) {
        event.preventDefault();
        var couponCode = $('#couponCode').val();

        // Appeler le script PHP pour vérifier et appliquer le coupon
        $.ajax({
            url: 'apply_coupon.php',
            method: 'POST',
            data: { couponCode: couponCode },
            success: function(response) {
                // Afficher la réponse du serveur (par exemple, un message de réussite ou d'erreur)
                alert(response);
				location.reload(true);
            }
        });
    });
});

</script>

<?php
include __DIR__."/footer.php";

