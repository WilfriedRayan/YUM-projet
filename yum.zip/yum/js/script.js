document.addEventListener('DOMContentLoaded', function() {
    var deleteLinks = document.getElementsByClassName('pt-delete');
  
    for (var i = 0; i < deleteLinks.length; i++) {
      deleteLinks[i].addEventListener('click', function(event) {
        event.preventDefault();
        
        var itemId = this.getAttribute('data-id');
        
        // Envoi de la requête AJAX
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'delete-order.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
          if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
              // Suppression réussie
              console.log('L\'élément a été supprimé avec succès.');
              // Actualiser la liste des éléments après la suppression
              // Vous pouvez appeler ici une fonction pour mettre à jour l'affichage de la liste
            } else {
              // Erreur lors de la suppression
              console.error('Une erreur s\'est produite lors de la suppression de l\'élément.');
            }
          }
        };
        xhr.send('id=' + encodeURIComponent(orderId));
      });
    }
  });