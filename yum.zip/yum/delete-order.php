<?php
include __DIR__."/configs.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérez les données envoyées en AJAX
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

    // Supprimez d'abord les références dans pl_notifications
    $sql = "DELETE FROM pl_notifications WHERE order_id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    // Ensuite, supprimez la commande de pl_orders
    $sql = "DELETE FROM pl_orders WHERE id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("i", $id);

    // Exécutez la requête
    if ($stmt->execute()) {
        // Retournez un code de succès
        echo json_encode(['success' => true]);
    } else {
        // Retournez un code d'erreur
        echo json_encode(['success' => false, 'message' => 'Erreur lors de la suppression de la commande']);
    }

    // Fermez la requête
    $stmt->close();
} else {
    // Retournez un code d'erreur pour une requête non-POST
    echo json_encode(['success' => false, 'message' => 'Méthode de requête non autorisée']);
}
?>
