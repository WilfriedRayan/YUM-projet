<?php
include __DIR__."/configs.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Récupérez les données envoyées en AJAX
  $type = isset($_POST['type']) ? $_POST['type'] : '';
  $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

  // Vérifiez le type d'élément à supprimer
  if ($type === 'coupon') {
      // Préparez la requête SQL pour supprimer le coupon
      $sql = "DELETE FROM pl_coupons WHERE id = ?";
      $stmt = $db->prepare($sql);
      $stmt->bind_param("i", $id);

      // Exécutez la requête
      if ($stmt->execute()) {
          // Retournez un code de succès
          echo json_encode(['success' => true]);
      } else {
          // Retournez un code d'erreur
          echo json_encode(['success' => false, 'message' => 'Erreur lors de la suppression du coupon']);
      }
  } else {
      // Retournez un code d'erreur pour un type d'élément inconnu
      echo json_encode(['success' => false, 'message' => 'Type d\'élément inconnu']);
  }
}

?>