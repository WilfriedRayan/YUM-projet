<?php
include __DIR__."/configs.php";
error_reporting(0);

if (empty($_POST['couponCode'])) {
    echo "Your coupon field is empty.";
} else {
    $promocode = $_POST['couponCode'];

    // Requête pour récupérer les détails du coupon
    $sql = "SELECT * FROM pl_coupons JOIN pl_restaurants ON pl_coupons.restau_id = pl_restaurants.id WHERE coupon_code = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("s", $promocode);
    $stmt->execute();
    $result = $stmt->get_result();

    // Vérifier si le coupon existe et est actif
    if ($result->num_rows > 0) {
        $coupon = $result->fetch_assoc();
        $restauId = $coupon['restau_id'];

        // Vérifier si le coupon est actif et n'est pas expiré
        if ($coupon['active'] == 1 && $coupon['expiration_date'] >= date('Y-m-d')) {
            $sql = "SELECT * FROM pl_items WHERE restaurant = ?";
            $stmt = $db->prepare($sql);
            $stmt->bind_param("i", $restauId);
            $stmt->execute();
            $rs = $stmt->get_result();
            $row = $rs->fetch_assoc();

            // Mettez le reste de votre code ici
            $amount = $row['selling_price'];
            $id = $row['id'];
            //echo $amount;

            // Calculer le montant de réduction à appliquer
            if (!isset($_SESSION['finalAmount'])) {
                $discountPercentage = $coupon['discount_percentage'];
                $discountAmount = ($amount * $discountPercentage) / 100;
                $finalAmount = $amount - $discountAmount;
                $finalAmountFormatted = number_format($finalAmount, 2, '.', '');

                // Arrondir le résultat à deux décimales après la virgule
                //$finalAmount = round($finalAmount, 2);

                // Stocker le finalAmount dans la session
                $_SESSION['finalAmount'] = $finalAmountFormatted;
                $sql = "UPDATE pl_items SET selling_price = ? WHERE id = ?";
                $stmt = $db->prepare($sql);
                $stmt->bind_param("di", $finalAmountFormatted, $id);
                $stmt->execute();

                echo "Well done! Pay now by Paypal to apply the upgrade price";
            } else {
                // Récupérer le finalAmount depuis la session
                $finalAmountFormatted = $_SESSION['finalAmount'];
            }

            if (isset($_SESSION['finalAmount'])){
                echo "The operation has already been performed.";
            }
        } else {

        $sql2 = "UPDATE pl_coupons SET Active = 0 WHERE expiration_date < CURRENT_DATE AND Active = 1";

// Exécuter la requête
if ($db->query($sql2) === TRUE) {
    $sql2;
} else {
    echo "Erreur lors de la mise à jour des coupons: " . $db->error;
}

            echo "Coupon code expired.";
        }
    } else {
        echo "Invalid coupon code.";
    }
}
?>