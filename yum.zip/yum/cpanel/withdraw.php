<?php
if(isset($_GET['user_id']) && isset($_GET['restau_id'])) {
    // Récupérez l'ID de l'utilisateur depuis les paramètres de l'URL
    $userId = $_GET['user_id'];
    $restaurantId = $_GET['restau_id'];
    
    // Maintenant vous pouvez effectuer des manipulations avec $userId et $restaurantId
    //echo "L'ID de l'utilisateur est : " . $userId;
} else {
    // Gérer le cas où l'ID de l'utilisateur n'est pas présent dans l'URL
    //echo "ID d'utilisateur ou ID de restaurant non trouvé dans l'URL";
}
?>

<div class="pt-breadcrumb">
	<div class="pt-title">
		<i class="fas fa-hand-holding-usd ic"></i> <?=$lang['dash']['withdraw']?>
		<p><a href="<?=path?>"><?=$lang['header']['dashboard']?></a> <i class="fas fa-long-arrow-alt-right"></i> <?=$lang['dash']['withdraw']?></p>
	</div>
	<div class="pt-options">
	<a href="#" onclick="refreshPage()" class="pt-btn"><i class="fas fa-sync"></i> <?=$lang['dash']['refresh']?> </a>
	</div>
</div>

<?php if(us_level == 6): ?>

	<div class="pt-resaurants">
	<div class="pt-resaurant">
		<div class="table-responsive">
	<table class="table">
		<thead>
			<tr>
				<th scope="col"><?=$lang['dash']['p_user']?></th>
				<th scope="col" class="text-center"></th>
				<th scope="col" class="text-center"><?=$lang['dash']['p_amount']?></th>
				<th scope="col" class="text-center"><?=$lang['dash']['p_paymentid']?></th>
				<th scope="col" class="text-center"><?=$lang['created_at']?></th>
				<th scope="col" class="text-center"><?=$lang['accepted_at']?></th>
				<th scope="col" class="text-center"></th>
			</tr>
		</thead>
		<tbody>
			<?php
			$sql = $db->query("SELECT * FROM ".prefix."withdraws ORDER BY id DESC LIMIT {$startpoint} , {$limit}") or die ($db->error);
			if($sql->num_rows):
			while($rs = $sql->fetch_assoc()):
			?>
			<tr>
				<td width="40%">
					<div class="pt-thumb">
						<img src="<?=db_get("users", "photo", $rs['author'])?>" onerror="this.src='<?=nophoto?>'" />
					</div>
					<a href="#" class="pt-name"><?=fh_user($rs['author'])?></a>
				</td>
				<td class="text-center">
					<span class="badge bg-<?=( $rs['status']=='0' ? 'gy' : ( $rs['status']=='1' ? 'gr' : 'r'))?>">
						<?=( $rs['status']=='0' ? 'In proccess' : ( $rs['status']=='1' ? 'Completed' : 'Declined'))?>
					</span>
				</td>
				<td class="text-center"><b><?=($rs['price']?$rs['price'] .dollar_sign :'--')?></b></td>
				<td class="text-center"><?=($rs['email']?$rs['email']:'--')?></td>
				<td class="text-center"><?=fh_ago($rs['created_at'])?></td>
				<td class="text-center"><?=( $rs['accepted_at'] ? fh_ago($rs['accepted_at']) : '--')?></td>
				<td class="pt-dot-options">
					<a class="pt-options-link"><i class="fas fa-ellipsis-h"></i></a>
					<ul class="pt-drop">
						<li><a href="#" class="pt-accept" data-id="<?=$rs['id']?>"><i class="fas fa-check"></i> <?=$lang['dash']['accept']?></a></li>
						<li><a href="#" class="pt-refuse" data-id="<?=$rs['id']?>"><i class="fas fa-times"></i> <?=$lang['dash']['refuse']?></a></li>
					</ul>
				</td>
			</tr>
			<?php
			endwhile;
			echo '<tr><td colspan="6">'.fh_pagination("withdraws",$limit, path."/dashboard.php?pg=withdraw&").'</td></tr>';
			else:
				?>
				<tr>
					<td colspan="6">
						<?=fh_alerts($lang['alerts']["no-data"], "info")?>
					</td>
				</tr>
				<?php
			endif;
			$sql->close();
			?>
		</tbody>
	</table>
	</div>
	</div>
</div>

<?php elseif(us_level == 4): ?>

<div class="pt-resaurants">
	<div class="pt-resaurant">
		<div class="table-responsive">
	<table class="table">
		<thead>
			<tr>
				<th scope="col"><?=$lang['dash']['p_user']?></th>
				<th scope="col" class="text-center"></th>
				<th scope="col" class="text-center"><?=$lang['dash']['p_amount']?></th>
				<th scope="col" class="text-center"><?=$lang['dash']['p_paymentid']?></th>
				<th scope="col" class="text-center"><?=$lang['created_at']?></th>
				<th scope="col" class="text-center"><?=$lang['accepted_at']?></th>
				<th scope="col" class="text-center"></th>
			</tr>
		</thead>
		<tbody>
			<?php
			$sql = $db->query("SELECT * FROM ".prefix."withdraws author='{$userId}' ORDER BY id DESC LIMIT {$startpoint} , {$limit}") or die ($db->error);
			if($sql->num_rows):
			while($rs = $sql->fetch_assoc()):
			?>
			<tr>
				<td width="40%">
					<div class="pt-thumb">
						<img src="<?=db_get("users", "photo", $rs['author'])?>" onerror="this.src='<?=nophoto?>'" />
					</div>
					<a href="#" class="pt-name"><?=fh_user($rs['author'])?></a>
				</td>
				<td class="text-center">
					<span class="badge bg-<?=( $rs['status']=='0' ? 'gy' : ( $rs['status']=='1' ? 'gr' : 'r'))?>">
						<?=( $rs['status']=='0' ? 'In proccess' : ( $rs['status']=='1' ? 'Completed' : 'Declined'))?>
					</span>
				</td>
				<td class="text-center"><b><?=($rs['price']?$rs['price'] .dollar_sign :'--')?></b></td>
				<td class="text-center"><?=($rs['email']?$rs['email']:'--')?></td>
				<td class="text-center"><?=fh_ago($rs['created_at'])?></td>
				<td class="text-center"><?=( $rs['accepted_at'] ? fh_ago($rs['accepted_at']) : '--')?></td>
				<td class="pt-dot-options">
					<a class="pt-options-link"><i class="fas fa-ellipsis-h"></i></a>
					<ul class="pt-drop">
						<li><a href="#" class="pt-refuse" data-id="<?=$rs['id']?>"><i class="fas fa-times"></i>Cancel</a></li>
					</ul>
				</td>
			</tr>
			<?php
			endwhile;
			echo '<tr><td colspan="6">'.fh_pagination("withdraws",$limit, path."/dashboard.php?pg=withdraw&").'</td></tr>';
			else:
				?>
				<tr>
					<td colspan="6">
						<?=fh_alerts($lang['alerts']["no-data"], "info")?>
					</td>
				</tr>
				<?php
			endif;
			$sql->close();
			?>
		</tbody>
	</table>
	</div>
	</div>
</div>

<?php endif; ?>

<script>
    function refreshPage() {
        window.location.reload(true);
    }
</script>