<?php

// Vérifiez si l'ID de l'utilisateur est disponible dans la variable de session
if(isset($_GET['user_id']) && isset($_GET['restau_id'])) {
    // Récupérez l'ID de l'utilisateur depuis les paramètres de l'URL
    $userId = $_GET['user_id'];
    $restaurantId = $_GET['restau_id'];
    
    // Maintenant vous pouvez effectuer des manipulations avec $userId et $restaurantId
    //echo "L'ID de l'utilisateur est : " . $userId;
} else {
    // Gérer le cas où l'ID de l'utilisateur n'est pas présent dans l'URL
    //echo "ID d'utilisateur ou ID de restaurant non trouvé dans l'URL";
}

function convertirNombre($nombre) {
    $nombreArrondi = round($nombre, 2); // Arrondi à 2 décimales
    
    if (floor($nombreArrondi) == $nombreArrondi) {
        return intval($nombreArrondi); // Convertit en entier si les décimales sont égales à zéro
    } else {
        return $nombreArrondi; // Retourne le nombre avec les décimales s'il y en a
    }
}

function convertRelativeDate($date) {
    $currentDate = new DateTime();
    $providedDate = new DateTime($date);
    $interval = $providedDate->diff($currentDate);
    
    $days = $interval->format('%a');
    $hours = $interval->format('%h');
    $minutes = $interval->format('%i');
    $seconds = $interval->format('%s');
    
    if ($days > 0) {
        return "{$days} days ago";
    } elseif ($hours > 0) {
        return "{$hours} hours ago";
    } elseif ($minutes > 0) {
        return "{$minutes} minutes ago";
    } elseif ($seconds > 0) {
        return "{$seconds} seconds ago";
    } else {
        return "Just now";
    }
}

?>

<?php if(us_level == 6): ?>

<div class="pt-breadcrumb">
	<div class="pt-title">
		<i class="icon-tag icons ic"></i> <?=$lang['dash']['coupons']?>
		<p>
			<a href="<?=path?>">Dashboard</a> <i class="fas fa-long-arrow-alt-right"></i> <?=$lang['dash']['coupons']?>
		</p>
	</div>
    <?php if(us_level == 6) : ?>
	<div class="pt-options">
	    <a href="#" onclick="refreshPage()" class="pt-btn"><i class="fas fa-sync"></i> <!-- Icône de rafraîchissement --></a>
		<a href="<?=path?>/dashboard.php?pg=coupons&request=new" class="pt-btn"><i class="fas fa-plus"></i> New Coupon</a>
	</div>
	<?php else : ?>
		<div><p>Acces Denied</p></div>
	<?php endif ?>
</div>

<?php if ($request == "new"): ?>
	<div class="pt-box p-5">
<?php include __DIR__ . '/../partials/newcoupon.php'; ?>
</div>
<?php else: ?>
<div class="pt-resaurants">
	<div class="pt-resaurant">
		<div class="table-responsive">
		<table class="table">
			<thead>
				<th colspan="2">Coupon code</th>
				<th class="text-center">Percentage (%)</th>
				<th class="text-center">Expiration date</th>
				<th class="text-center">Active</th>
				<th class="text-center">Created at</th>
				<th></th>
			</thead>
			<tbody>
			
				<?php
				$query = "SELECT pl_coupons.*, pl_restaurants.name FROM pl_coupons JOIN pl_restaurants ON pl_coupons.restau_id = pl_restaurants.id";
				$sql = $db->query($query);
				if($sql->num_rows):
				while($rs = $sql->fetch_assoc()):
				?>
				<tr>

                    <th width="1" style="margin-right: 5px"><div class="pt-thumb m-0"></div></th>
					<td>
						<h3 style="margin: 2px; padding-rigth: 20px"><a href="#"><?=$rs['coupon_code']?></a></h3>
						<p><span><i class="fas fa-store"></i> <?=$rs['name']?></span></p>
					</td>
                    <td class="text-center"><?= convertirNombre($rs['discount_percentage']) ?></td>
					<td class="text-center"><?=$rs['expiration_date']?></td>
                    <td class="text-center"><?=$rs['active'] || $rs['expiration_date'] > date('Y-m-d') ? "Valid" : "Invalid"?></td>
					<td class="text-center"><?= convertRelativeDate($rs['created_at']) ?></td>
					<td class="pt-dot-options">
						<a class="pt-options-link"><i class="fas fa-ellipsis-h"></i></a>
						<ul class="pt-drop">
							<li><a href="<?=path?>/index.php" /*class="pt-itemhome"*/ data-id="<?=$rs['id']?>"><i class="fas fa-home"></i> <?=$lang['dash']['athome']?></a></li>
							<li><a href="#" class="delete-btn" data-type="coupon" data-id="<?=$rs['id']?>"><i class="fas fa-trash-alt"></i> Delete</a></li>
						</ul>
					</td>
				</tr>
				<?php endwhile; ?>
				<?php else: ?>
					<tr>
						<td colspan="7" class="text-center"><?=$lang['alerts']['no-data']?></td>
					</tr>
				<?php endif; ?>
				<?php endif; ?>
				<?php $sql->close(); ?>
			</tbody>
		</table>
		</div>
	</div>

</div>


<?php elseif(us_level == 4) : ?>

	<div class="pt-breadcrumb">
	<div class="pt-title">
		<i class="icon-tag icons ic"></i> <?=$lang['dash']['coupons']?>
		<p>
			<a href="<?=path?>">Dashboard</a> <i class="fas fa-long-arrow-alt-right"></i> <?=$lang['dash']['coupons']?>
		</p>
	</div>

	<div class="pt-options">
	   <a href="#" onclick="refreshPage()" class="pt-btn"><i class="fas fa-sync"></i> <!-- Icône de rafraîchissement --></a>
	   <a href="<?=path?>/restau_dashboard.php?pg=coupons&request=new&user_id=<?= $userId ?>&restau_id=<?= $restaurantId ?>" class="pt-btn"><i class="fas fa-plus"></i> New Coupon</a>
	</div>
</div>

<?php if ($request == "new"): ?>
	<div class="pt-box p-5">
<?php include __DIR__ . '/../partials/newcoupon.php'; ?>
</div>
<?php else: ?>
<div class="pt-resaurants">
	<div class="pt-resaurant">
		<div class="table-responsive">
		<table class="table">
			<thead>
				<th colspan="2">Coupon code</th>
				<th class="text-center">Percentage (%)</th>
				<th class="text-center">Expiration date</th>
				<th class="text-center">Active</th>
				<th class="text-center">Created at</th>
				<th></th>
			</thead>
			<tbody>
			
				<?php
				$query = "SELECT pl_coupons.*, pl_restaurants.name FROM pl_coupons JOIN pl_restaurants ON pl_coupons.restau_id = pl_restaurants.id WHERE pl_restaurants.id = '{$restaurantId}'";
				$sql = $db->query($query);
				if($sql->num_rows):
				while($rs = $sql->fetch_assoc()):
				?>
				<tr>

                    <th width="1" style="margin-right: 5px"><div class="pt-thumb m-0"></div></th>
					<td>
						<h3 style="margin: 2px; padding-rigth: 20px"><a href="#"><?=$rs['coupon_code']?></a></h3>
						<p><span><i class="fas fa-store"></i> <?=$rs['name']?></span></p>
					</td>
                    <td class="text-center"><?= convertirNombre($rs['discount_percentage']) ?></td>
					<td class="text-center"><?=$rs['expiration_date']?></td>
                    <td class="text-center"><?=$rs['active'] ? "Valid" : "Invalid"?></td>
					<td class="text-center"><?= convertRelativeDate($rs['created_at']) ?></td>
					<td class="pt-dot-options">
						<a class="pt-options-link"><i class="fas fa-ellipsis-h"></i></a>
						<ul class="pt-drop">
							<li><a href="#" class="pt-itemhome" data-id="<?=$rs['id']?>"><i class="fas fa-home"></i> <?=$lang['dash']['athome']?></a></li>
							<li><a href="#" class="delete-btn" data-type="coupon" data-id="<?=$rs['id']?>"><i class="fas fa-trash-alt"></i> Delete</a></li>
						</ul>
					</td>
				</tr>
				<?php endwhile; ?>
				<?php else: ?>
					<tr>
						<td colspan="7" class="text-center"><?=$lang['alerts']['no-data']?></td>
					</tr>
				<?php endif; ?>
				<?php endif; ?>
				<?php $sql->close(); ?>
			</tbody>
		</table>
		</div>
	</div>

</div>

<?php endif; ?>

<script>

/////Delete coupon 

document.querySelectorAll('.delete-btn').forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault();
        let type = event.target.dataset.type;
        let id = event.target.dataset.id;

        // Demander la confirmation à l'utilisateur
        var confirmation = confirm('Are you sure you want to delete this coupon?');

        if (confirmation) {
            // Envoyez une requête AJAX pour supprimer l'élément
            fetch('delete-coupon.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({ type, id })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Supprimez l'élément du DOM
                    event.target.closest('tr').remove();
					//Actualisez la page
					window.location.reload();
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Erreur lors de la suppression :', error);
                alert('Une erreur est survenue lors de la suppression.');
            });
        }
    });
});

//////////////////Reload page after any activity

function refreshPage() {
    // Appeler le script PHP pour mettre à jour le statut des coupons
    fetch('update_coupon_status.php')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Si la mise à jour a réussi, recharger la page
                location.reload(true);
            } else {
                console.error('Erreur lors de la mise à jour:', data.message);
            }
        })
        .catch(error => {
            console.error('Erreur de réseau:', error);
        });
}

</script>
