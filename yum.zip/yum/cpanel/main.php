<?php 

include __DIR__."/configs.php";

if(isset($_GET['user_id']) && isset($_GET['restau_id'])) {
    // Récupérez l'ID de l'utilisateur depuis les paramètres de l'URL
    $userId = $_GET['user_id'];
    $restaurantId = $_GET['restau_id'];
    
    // Maintenant vous pouvez effectuer des manipulations avec $userId et $restaurantId
    //echo "L'ID de l'utilisateur est : " . $userId;
} else {
    // Gérer le cas où l'ID de l'utilisateur n'est pas présent dans l'URL
    //echo "ID d'utilisateur ou ID de restaurant non trouvé dans l'URL";
}

$total_items = 0;
$total_orders = 0;
$total_menus = 0;
$total_ip_orders = 0;
$total_de_orders = 0;
$orderAmount = fh_cp_amount("orders", "payment_amount", "GROUP BY transaction_id");
if (us_level == 4) {
    $total_items = db_rows("items WHERE restaurant='{$restaurantId}'");
	$total_orders = db_rows("orders WHERE restaurant='{$restaurantId}'");
	$total_menus = db_rows("menus WHERE restaurant='{$restaurantId}'");
	$total_reviews = db_rows("reviews WHERE restaurant='{$restaurantId}'");
	$total_cuisines = db_rows("cuisines WHERE restaurant_id='{$restaurantId}'");
} elseif (us_level == 6) {
    $total_items = db_rows("items");
	$total_orders = db_rows("orders");
	$total_menus = db_rows("menus");
} elseif (us_level == 2) {
	$us_id = us_id;

	$query = "SELECT COUNT(*) AS total FROM pl_orders WHERE driver_id = " . $us_id . " AND status = 0";
	$response = $db->query($query);
	$row = $response->fetch_assoc();
	$total_orders = $row['total'];

	$ip_query = "SELECT COUNT(*) AS ip_total FROM pl_orders WHERE driver_id = " . $us_id . " AND status = 1";
	$ip_res = $db->query($ip_query);
	$ip_row = $ip_res->fetch_assoc();
	$total_ip_orders = $ip_row['ip_total'];

	$de_query = "SELECT COUNT(*) AS de_total FROM pl_orders WHERE driver_id = " . $us_id . " AND status = 2";
	$de_res = $db->query($de_query);
	$de_row = $de_res->fetch_assoc();
	$total_de_orders = $de_row['de_total'];
}   

?>

<ul class="pt-main-stats">
	<li>
	    <?php if(us_level==6 || us_level==4): ?>
		<div class="pt-box">
			<span><i class="icon-wallet icons"></i></span>
			<b><?= $total_orders ?></b><br /><small>Total Orders</small>
		</div>
		<?php elseif(us_level == 2): ?>
			<div class="pt-box">
			<span><i class="icon-wallet icons"></i></span>
			<b><?= $total_orders ?></b><br /><small>Orders assigned</small>
		</div>
		<?php endif; ?>
	</li>
	<?php if(us_level == 2): ?>
	<li>
		<div class="pt-box">
			<span><i class="fas fa-spinner fa-spin"></i></span>
			<b><?= $total_ip_orders ?></b><br /><small>In process</small>
		</div>
	</li>
	<?php endif; ?>
	<?php if(us_level == 2): ?>
	<li>
			<div class="pt-box">
			<span><i class="fas fa-check-circle" style="color: orange;"></i></span>
			<b><?= $total_de_orders ?></b><br /><small>Total delivered</small>
		</div>
	</li>
	<?php endif; ?>
	<li>
		<div class="pt-box">
			<span><i class="fas fa-coins"></i></span>
			<b><?=db_rows("payments")?></b><br /><small>Total Payments</small>
		</div>
	</li>

	<?php if(us_level == 6): ?>
    <li>
        <div class="pt-box">
            <span><i class="fas fa-store"></i></span>
            <b><?=db_rows("restaurants")?></b><br /><small>Total Restaurants</small>
        </div>
    </li>
    <?php elseif(us_level == 4): ?>
    <li>
        <div class="pt-box">
            <span><i class="fas fa-book"></i></span>
            <b><?= $total_menus ?></b><br /><small>Total Menus</small>
        </div>
    </li>
    <?php endif; ?>
    
	<?php if(us_level==6 || us_level==4): ?>
    <li>
      <div class="pt-box">
        <span><i class="fas fa-pizza-slice"></i></span>
        <b><?= $total_items ?></b><br /><small>Total Items</small>
      </div>
    </li>
	<?php endif; ?>
	
</ul>

<ul class="pt-main-stats">
	<li class="thr">
		<?php if(us_level == 6): ?>
			<div class="pt-box">
			<span><i class="fas fa-comments-dollar"></i></span>
			<b><?=$orderAmount?></b><br /><small>Orders amount</small>
		</div>
		<?php elseif(us_level == 4): ?>
            <div class="pt-box">
			<span><i class="fas fa-comments-dollar"></i></span>
			<b><?=fh_cp_amount("orders", "payment_amount", "WHERE restaurant='{$restaurantId}' GROUP BY transaction_id")?></b><br /><small>Orders amount</small>
		</div>
		<?php endif; ?>
	</li>
	<li class="thr">
	<?php if(us_level == 6): ?>
		<div class="pt-box">
			<span><i class="fas fa-file-invoice-dollar"></i></span>
			<b><?=fh_cp_amount("payments", "price")?></b><br /><small>Payments amount</small>
		</div>
	<?php elseif(us_level == 4): ?>
		<div class="pt-box">
			<span><i class="fas fa-star"></i></span>
			<b><?= $total_reviews ?></b><br /><small>All reviews</small>
		</div>
		<?php endif; ?>

	</li>
	<li class="thr">
	<?php if(us_level == 6): ?>
		<div class="pt-box">
			<span><i class="fas fa-search-dollar"></i></span>
			<b><?=fh_cp_amount("taxes", "taxes")?></b><br /><small>Taxes amount</small>
		</div>
	<?php elseif(us_level == 4): ?>
		<div class="pt-box">
			<span><i class="fas fa-utensils"></i></span>
			<b><?= $total_cuisines ?></b><br /><small>Meals cuisines</small>
		</div>
	<?php endif; ?>

	</li>
</ul>

<div class="row">
	<div class="col-8">
		<div class="pt-order-chart pt-box">
			<h3>
				Orders Statistics
				<span class="ptcporders" rel="days">Days</span>
				<span class="ptcporders" rel="months">Months</span>
			</h3>
			<div class="p-4 pl-5 pr-5"><canvas id="orders-cporders"></canvas></div>

		</div>
	</div>
	<div class="col-4">
		<div class="pt-order-chart pt-box">
			<h3>Orders by gender</h3>
			<div class="p-4"><canvas id="orders-cpgender"></canvas></div>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-3">
		<div class="pt-order-chart pt-box">
			<h3>24h Payments</h3>
			<div class="pt-content">
				<ul>
					<?php
					$sql = $db->query("SELECT * FROM ".prefix."payments WHERE date >= '".(time() - 3600*24)."' ORDER BY id DESC") or die ($db->error);
					if($sql->num_rows):
					while($rs = $sql->fetch_assoc()):
					?>
					<li>
						<div class="media">
							<div class="media-left">
								<div class="pt-thumb"><img src="<?=db_get("users", "photo", $rs['author'])?>" onerror="this.src='<?=nophoto?>'" /></div>
							</div>
							<div class="media-body">
								<?=fh_user($rs['author'])?>
								<p>
									<span><i class="far fa-clock"></i> <?=fh_ago($rs['date'])?></span>
									<span><i class="fas fa-comment-dollar"></i> $<?=$rs['price']?></span>
								</p>
							</div>
						</div>
					</li>
					<?php
					endwhile;
					else:
						echo '<li class="text-center">'.$lang['alerts']['no-data'].'</li>';
					endif;
					$sql->close();
					?>
				</ul>
			</div>
		</div>
	</div>
	<div class="col-3">
		<div class="pt-order-chart pt-box">
			<h3>24h Orders</h3>
			<div class="pt-content pt-scroll">
				<ul>
					<?php
					$sql = $db->query("SELECT * FROM ".prefix."orders WHERE created_at >= '".(time() - 3600*24)."' ORDER BY id DESC") or die ($db->error);
					if($sql->num_rows):
					while($rs = $sql->fetch_assoc()):
						$cart = json_decode($rs['order_cart'], true);
						$rsi  = db_rs("items WHERE id = '{$cart['item_id']}'");
						$item_size = isset($cart['item_size']) ? db_unserialize([$rsi['sizes'], $cart['item_size']]) : '';
					?>
					<li>
						<div class="media">
							<div class="media-left">
								<div class="pt-thumb"><img src="<?=$rsi['image']?>" onerror="this.src='<?=noimage?>'" /></div>
							</div>
							<div class="media-body">
								<a href="<?=path?>/restaurants.php?id=<?=$rsi['restaurant']?>&t=<?=fh_seoURL(db_get("restaurants", "name", $rsi['restaurant']))?>"><?=$rsi['name']?></a>

								<p>
									<span><i class="far fa-clock"></i> <?=fh_ago($rs['created_at'])?></span>
									<span><i class="fas fa-money-bill-wave"></i> <?=$cart['item_quantities']?> x <?=dollar_sign.($item_size ? $item_size['price'] : $rsi['selling_price'])?></span>
								</p>
							</div>
						</div>
					</li>
					<?php
					endwhile;
					else:
						echo '<li class="text-center">'.$lang['alerts']['no-data'].'</li>';
					endif;
					$sql->close();
					?>
				</ul>
			</div>
		</div>
	</div>
	<div class="col-3">
		<div class="pt-order-chart pt-box">
			<h3>24h Restaurants</h3>
			<div class="pt-content pt-scroll">
				<ul>
					<?php
					$sql = $db->query("SELECT * FROM ".prefix."restaurants WHERE created_at >= '".(time() - 3600*24)."' ORDER BY id DESC") or die ($db->error);
					if($sql->num_rows):
					while($rs = $sql->fetch_assoc()):
					?>
					<li>
						<div class="media">
							<div class="media-left">
								<div class="pt-thumb"><img src="<?=$rs['photo']?>" onerror="this.src='<?=noimage?>'" /></div>
							</div>
							<div class="media-body">
								<a href="<?=path?>/restaurants.php?id=<?=$rs['id']?>&t=<?=fh_seoURL($rs['name'])?>"><?=$rs['name']?></a>

								<p>
									<span><i class="far fa-clock"></i> <?=fh_ago($rs['created_at'])?></span>
									<span><i class="fas fa-poll"></i> <?=db_rows("items WHERE restaurant = '{$rs['id']}'")?> items</span>
								</p>
							</div>
						</div>
					</li>
					<?php
					endwhile;
					else:
						echo '<li class="text-center">'.$lang['alerts']['no-data'].'</li>';
					endif;
					$sql->close();
					?>
				</ul>
			</div>
		</div>
	</div>
	<div class="col-3">
		<div class="pt-order-chart pt-box">
			<h3>24h Items</h3>
			<div class="pt-content pt-scroll">
				<ul>
					<?php
					$sql = $db->query("SELECT * FROM ".prefix."items WHERE created_at >= '".(time() - 3600*24)."' ORDER BY id DESC") or die ($db->error);
					if($sql->num_rows):
					while($rs = $sql->fetch_assoc()):
					?>
					<li>
						<div class="media">
							<div class="media-left">
								<div class="pt-thumb"><img src="<?=$rs['image']?>" onerror="this.src='<?=noimage?>'" /></div>
							</div>
							<div class="media-body">
								<a href="<?=path?>/restaurants.php?id=<?=$rs['restaurant']?>&t=<?=fh_seoURL(db_get("restaurants", "name", $rs['restaurant']))?>"><?=$rs['name']?></a>

								<p>
									<span><i class="far fa-clock"></i> <?=fh_ago($rs['created_at'])?></span>
									<span><i class="fas fa-poll"></i> <?=db_rows("orders WHERE item = '{$rs['id']}'")?> items</span>
								</p>
							</div>
						</div>
					</li>
					<?php
					endwhile;
				    else:
						echo '<li class="text-center">'.$lang['alerts']['no-data'].'</li>';
					endif;
					$sql->close();
					?>
				</ul>
			</div>
		</div>
	</div>
</div>
