<?php

if(isset($_GET['user_id']) || isset($_GET['restau_id'])) {
    // Récupérez l'ID de l'utilisateur depuis les paramètres de l'URL
    $userId = $_GET['user_id'];
    $restaurantId = $_GET['restau_id'];
    
    // Maintenant vous pouvez effectuer des manipulations avec $userId et $restaurantId
    //echo "L'ID de l'utilisateur est : " . $userId;
} else {
    // Gérer le cas où l'ID de l'utilisateur n'est pas présent dans l'URL
    //echo "ID d'utilisateur ou ID de restaurant non trouvé dans l'URL";
}

?>

<div class="pt-breadcrumb">
	<div class="pt-title">
		<i class="icon-star icons ic"></i> <?=$lang['dash']['reviews']?>
		<p><a href="<?=path?>"><?=$lang['header']['dashboard']?></a> <i class="fas fa-long-arrow-alt-right"></i> <?=$lang['dash']['reviews']?></p>
	</div>
	<div class="pt-options">
	<a href="#" onclick="refreshPage()" class="pt-btn"><i class="fas fa-sync"></i> <?=$lang['dash']['refresh']?> </a>
	</div>
</div>

<?php if(us_level == 6): ?>

	<div class="pt-resaurants">
	<div class="pt-resaurant">
		<?php
		$sql = $db->query("SELECT * FROM ".prefix."reviews ORDER BY id DESC LIMIT {$startpoint} , {$limit}");
		if($sql->num_rows):
		while($rs = $sql->fetch_assoc()):
		?>
		<div class="pt-options" style="margin-right: 5px; margin-left: 1390px; padding-top: 2px; border-radius: 5px; background-color: red; cursor: pointer">
		   <a class="delete-link" href="#" data-review-id="<?php echo $rs['id']?>" style="margin-left: 9px; color: #fff;"> <i class="fas fa-times"></i></a>
		</div>
		<div class="pt-resaurant pt-reviews">
			<div class="modal-header">
				<div class="float-left">
					<?=fh_stars_alt($rs['stars'], 5-$rs['stars'])?>
					<b><?=$rs['title']?></b>
					<div><a href="<?=path?>/restaurants.php?id=<?=$rs['restaurant']?>&t=<?=fh_seoURL(db_get("restaurants", "name", $rs['restaurant']))?>"><?=db_get("restaurants", "name", $rs['restaurant'])?></a></div>
				</div>

				<div class="float-right">
					by <?php echo fh_user($rs['author']) ?> - <?php echo fh_ago($rs['created_at']) ?>
				</div>
			</div>
			<p><?=$rs['content']?></p>
		</div>
		<?php endwhile; ?>
		<?php else: ?>
			<div class="text-center"><?=$lang['alerts']['no-data']?></div>
		<?php endif; ?>
		<?php $sql->close(); ?>
		<?php echo fh_pagination("reviews",$limit, path."/dashboard.php?pg=reviews&") ?>
	</div>
	
</div>

<?php elseif(us_level == 4): ?>

	<div class="pt-resaurants">
	<div class="pt-resaurant">
		<?php
		$sql = $db->query("SELECT * FROM ".prefix."reviews WHERE restaurant = '{$restaurantId}' ORDER BY id DESC LIMIT {$startpoint} , {$limit}");
		if($sql->num_rows):
		while($rs = $sql->fetch_assoc()):
		?>
		<div class="pt-options" style="margin-right: 5px; margin-left: 1390px; padding-top: 2px; border-radius: 5px; background-color: red; cursor: pointer">
		   <a class="delete-link" href="#" data-review-id="<?php echo $rs['id']?>" style="margin-left: 9px; color: #fff;"> <i class="fas fa-times"></i></a>
		</div>
		<div class="pt-resaurant pt-reviews">
			<div class="modal-header">
				<div class="float-left">
					<?=fh_stars_alt($rs['stars'], 5-$rs['stars'])?>
					<b><?=$rs['title']?></b>
					<div><a href="<?=path?>/restaurants.php?id=<?=$rs['restaurant']?>&t=<?=fh_seoURL(db_get("restaurants", "name", $rs['restaurant']))?>"><?=db_get("restaurants", "name", $rs['restaurant'])?></a></div>
				</div>

				<div class="float-right">
					by <?php echo fh_user($rs['author']) ?> - <?php echo fh_ago($rs['created_at']) ?>
				</div>
			</div>
			<p><?=$rs['content']?></p>
		</div>
		<?php endwhile; ?>
		<?php else: ?>
			<div class="text-center"><?=$lang['alerts']['no-data']?></div>
		<?php endif; ?>
		<?php $sql->close(); ?>
		<?php echo fh_pagination("reviews",$limit, path."/dashboard.php?pg=reviews&") ?>
	</div>
	
</div>

<?php endif; ?>

<script>

document.addEventListener('DOMContentLoaded', function() {
    var deleteLinks = document.querySelectorAll('.delete-link');

    deleteLinks.forEach(function(link) {
      link.addEventListener('click', function(e) {
        e.preventDefault();
		var hasExecuted = false;

        var reviewId = this.getAttribute('data-review-id');

        var confirmation = confirm('Are you sure you want to delete this?');

        if (confirmation) {
          var xhr = new XMLHttpRequest();
          xhr.open('POST', 'delete-review.php', true);
          xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
          xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
              var response = JSON.parse(xhr.responseText);
              console.log('Review successfully deleted');
              //window.location.reload(true);
			  //window.location.href = window.location.href;
            } else if (xhr.readyState === 4 && xhr.status !== 200) {
              console.log('Erreur lors de la suppression du commentaire');
            }
          };

          xhr.send('id=' + encodeURIComponent(reviewId));

		  showDeleteNotification('Review successfully deleted !');
		  setTimeout(function() {
                    window.location.reload(true);
                    window.location.href = window.location.href;
        }, 1000);
        }
      });
	  
    });
  });

//// Fonction pour afficher une notification de suppression de commande
function showDeleteNotification(message) {
    // Vérifier si le navigateur prend en charge les notifications
    if ('Notification' in window) {
        // Vérifier si les notifications sont autorisées
        if (Notification.permission === 'granted') {
            // Créer une notification
            createNotification(message);
        } else if (Notification.permission !== 'denied') {
            // Demander la permission à l'utilisateur pour afficher les notifications
            Notification.requestPermission().then(function(permission) {
                if (permission === 'granted') {
                    // Créer une notification si la permission est accordée
                    createNotification(message);
                }
            });
        }
    }
}

function createNotification(message) {
    var notification = new Notification('Commentaire Supprimée', { body: message });

    // Gérer le clic sur la notification
    notification.onclick = function() {
        // Vous pouvez ajouter une action à effectuer lors du clic sur la notification
        console.log('Notification clicked');
    };

    // Fermer automatiquement la notification après quelques secondes
    setTimeout(function() {
        notification.close();
    }, 2000);
}

function refreshPage() {
    location.reload(true);
}


</script>