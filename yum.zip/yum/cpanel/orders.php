<?php 

if(isset($_GET['user_id']) || isset($_GET['restau_id']) || isset($_GET['driver_id'])) {
    // Récupérez l'ID de l'utilisateur depuis les paramètres de l'URL
    $userId = $_GET['user_id'];
	$driverId = $_GET['driver_id'];
    $restaurantId = $_GET['restau_id'];

    $driverId = us_id;
    // Maintenant vous pouvez effectuer des manipulations avec $userId et $restaurantId
    //echo "L'ID de l'utilisateur est : " . $userId;
} else {
    // Gérer le cas où l'ID de l'utilisateur n'est pas présent dans l'URL
    //echo "ID d'utilisateur ou ID de restaurant non trouvé dans l'URL";
}

?>

<style>

	.white-rectangle {
    background-color: #fff; /* Couleur de fond blanche */
    padding: 20px; /* Espace intérieur */
    border-radius: 5px; /* Bordures arrondies */
    /* Autres styles CSS selon vos préférences */
}

    .slider-container {
        display: flex;
        align-items: center;
    }

    .slider {
        -webkit-appearance: none;
        width: 40px; /* Largeur ajustée */
        height: 20px;
        border-radius: 10px;
        background: #FF9F0E;
        outline: none;
        margin: 0 10px;
        transition: all 0.5s ease; /* Transition pour l'arrière-plan */
    }

	.slider.available {
    background: #ff9f0e; /* Fond orange lorsque disponible */
}

.slider.unavailable {
    background: #F5F5F5; /* Fond blanc lorsque indisponible */
}

    .slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: white; /* Bouton blanc par défaut */
        cursor: pointer;
        transition: background-color 0.2s ease; /* Transition pour l'arrière-plan */
    }

    .slider::-moz-range-thumb {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: white; /* Bouton blanc par défaut */
        cursor: pointer;
        transition: background-color 0.5s ease; /* Transition pour l'arrière-plan */
    }

    .slider-container.available .slider {
        background: #FF9F0E; /* Arrière-plan orange pour disponible */
    }

    .slider-container.unavailable .slider {
        background: none; /* Retire l'arrière-plan pour indisponible */
    }

    .slider-container.available .slider::-webkit-slider-thumb,
    .slider-container.available .slider::-moz-range-thumb {
        background: #FF9F0E; /* Bouton orange pour disponible */
    }

    #status-label {
        color: #FF9F0E; /* Couleur par défaut pour disponible */
    }

</style>




<div class="pt-breadcrumb">
	<div class="pt-title">
		<i class="icon-wallet icons ic"></i> Orders
		<p>
			<?php if(us_level == 6): ?>
				<a href="<?=path?>/dashboard.php">Dashboard</a> <i class="fas fa-long-arrow-alt-right"></i> Orders
			<?php elseif(us_level== 4): ?>
				<a href="<?=path?>/restau_dashboard.php">Dashboard</a> <i class="fas fa-long-arrow-alt-right"></i> Orders
			<?php elseif(us_level == 2): ?>
				<a href="<?=path?>/deliverer_dashboard.php">Dashboard</a> <i class="fas fa-long-arrow-alt-right"></i> Orders
			<?php endif; ?>	
				
		</p>
	</div>

</div>

<?php if(us_level == 2): ?>
	<div class="white-rectangle">
    <div class="slider-container">
        <label for="status">Statut:</label>
        <input type="range" min="0" max="1" value="1" class="slider" id="status-slider">
        <span id="status-label">Disponible</span>
    </div>
</div>
<?php endif; ?>



<?php if(us_level == 6): ?>

	<div class="pt-resaurants pt-restaurantpage">
	<div class="pt-resaurant">
		<?php 
		$sql = $db->query("SELECT * FROM ".prefix."orders ORDER BY id DESC LIMIT {$startpoint} , {$limit}");
		if($sql->num_rows):
			$toott  = 0;
			$tshipp = 0;

		while($rs = $sql->fetch_assoc()):
			$cart = json_decode($rs['order_cart'], true);
			$billing = json_decode($rs['billing_info'], true);
			$sqli = $db->query("SELECT * FROM ".prefix."items WHERE id = '{$cart['item_id']}'");
			$rsi  = $sqli->fetch_assoc();
			$sqli->close();

			$item_size = isset($cart['item_size']) ? db_unserialize([$rsi['sizes'], $cart['item_size']]) : '';
			$driverSelectionId = 'driver-selection-' . $rs['id'];
		?>
		<div class="pt-cart-body">
			<div class="media">
				<div class="media-left"><div class="pt-thumb"><img src="<?=path?>/<?=$rsi['image']?>" alt="<?=$rsi['name']?>" onerror="this.src='<?=noimage?>'"></div></div>
				<div class="media-body">
					<div class="pt-dtable">
						<div class="pt-vmiddle">
							<div class="pt-title">
								<h3>
									<a href="#">
										<?=$rsi['name']?><?php if($item_size): ?><strong class="pt-color"> (<?=$item_size['name']?>)</strong><?php endif; ?>
									</a>
								</h3>
							</div>
							<div class="pt-extra">
								<strong><i class="fas fa-money-bill-wave"></i> <?=$cart['item_quantities']?> x <a><?=dollar_sign.(isset($cart['item_price']) ? $cart['item_price'] : ($item_size ? $item_size['price'] : $rsi['selling_price']))?></a></strong>
								<strong> - <i class="far fa-clock"></i> <?=fh_ago($rs['created_at'])?></strong>
								<strong> - <i class="fas fa-store"></i> <a href="<?=path?>/restaurants.php?id=<?=$rs['restaurant']?>&t=<?=fh_seoURL(db_get("restaurants", "name", $rs['restaurant']))?>"><?=db_get("restaurants", "name", $rs['restaurant'])?></a></strong>
							</div>
							<div class="pt-extra"><small><?=str_replace("+", " ", $cart['item_note'])?></small></div>
							<div class="pt-extra">
								<?php
								if($cart['item_extra']):
								foreach($cart['item_extra'] as $k => $extra):
									$extra = db_unserialize([$rsi['extra'], $extra]);
								?>
									<span>
										<?=$extra['name']?> <b class="pt-extraprice"><?=dollar_sign.$extra['price']?></b>
									</span>
								<?php
								endforeach;
								endif;
								?>
							</div>
							<div class="pt-options">
								<?php if($rs['status']==2): ?>
								<a class="pt-delivered wdth"><i class="fas fa-check"></i> Delivered</a>
								<?php elseif($rs['status']==1): ?>
								<a class="pt-awaiting wdth bg-v"><i class="fas fa-truck"></i> In the way</a>
								<?php else: ?>
								<a class="pt-awaiting wdth"><i class="fas fa-clock"></i> Awaiting</a>
								<?php endif; ?>
							    <a class="delete-link" href="#" data-id="<?=$rs['id']?>"> <i class="fas fa-trash"></i> </a>
								<?php if($rs['status']!=2): ?>
								<a href="#" class="pt-delivered tips" data-id="<?php echo $rs['id'] ?>"><i class="fas fa-check"></i><b>Make it delivered</b></a>
								<?php endif; ?>
								<?php if($rs['status']==0): ?>
								<a href="#" class="pt-intheway tips" data-id="<?php echo $rs['id'] ?>"><i class="fas fa-truck"></i><b>In the way</b></a>
								<?php endif; ?>
								<a href="#" class="pt-addinvoice tips" data-name="<?php echo time()."_".fh_seoURL($rsi['name']); ?>" data-id="<?php echo $rs['id']; ?>"><i class="fas fa-file-invoice-dollar"></i><b>Invoice</b></a>
								<!-- Bouton pour affecter un livreur -->
						    	<a href="#" class="pt-assign-driver tips" data-oid="<?=$rs['id']?>"><i class="fas fa-user"></i><b>Assign Driver</b></a>
                                
								<br><br>
								<!-- Boîte de sélection pour les livreurs -->
    <div id="<?=$driverSelectionId?>" style="display: none;">
        <select class="driver-list">
            <!-- Options des livreurs seront chargées dynamiquement -->
        </select>
        <button class="assign-button" style="display: flex; justify-content: center; align-items: center; width: 100%; height: 100%; background: #ff9f0e; color: #fff; border: 1px solid lightgray; border-radius: 5px;">Assign</button>
    </div>
							</div>
							

						</div>
					</div>
				</div>
			</div>
			<div class="pt-billing">
				<span><b>Full Name:</b> <?=str_replace("+", " ",$billing['name'])?></span>
				<span><b>Phone:</b> <?=$billing['phone']?></span><br />
				<span><b>Address:</b> <?=str_replace("+", " ",$billing['address'])?>, <?=str_replace("+", " ",$billing['city'])?>  <?=$billing['postal_code']?> - <?=str_replace("+", " ",$billing['state'])?>, <?=$billing['country']?></span>
			</div>
		</div>


		<div class="d-none">
		<div id="invoice_<?php echo $rs['id']; ?>">
			<h1 class="text-center mb-5">Invoice</h1>
			<div class="card">
				<?php
				$sqlr = $db->query("SELECT * FROM ".prefix."restaurants WHERE id = '{$rs['restaurant']}'");
				$rsr  = $sqlr->fetch_assoc();
				$sqlr->close();
				?>
				<div class="card-header">
					Invoice ID: <strong class="text-uppercase"><?php echo md5($rs['id']); ?></strong>
					<span class="float-right">Invoice Date: <strong><?php echo date("d/m/Y H:i"); ?></strong></span>
				</div>
				<div class="card-body">
					<div class="row mb-4">
						<div class="col-sm-6">
							<h6 class="mb-3">From:</h6>
							<div><strong><?php echo $rsr['name']; ?></strong></div>
							<div><?php echo $rsr['address']; ?></div>
							<div><?php echo $rsr['city']." ".$rsr['zipcode']." - ".$rsr['state'].", ".$rsr['country']; ?></div>
							<div>Email: <?php echo $rsr['email']; ?></div>
							<div>Phone: <?php echo $rsr['phone']; ?></div>
						</div>

						<div class="col-sm-6">
							<h6 class="mb-3">To:</h6>
							<div><strong><?php echo str_replace("+", " ",$billing['name']); ?></strong></div>
							<div><?php echo str_replace("+", " ",$billing['address']); ?></div>
							<div><?php echo str_replace("+", " ",$billing['city'])." ".$billing['postal_code']." - ".str_replace("+", " ",$billing['state']).", ".$billing['country']; ?></div>
							<div>Email: <?php echo $billing['email']; ?></div>
							<div>Phone: <?php echo $billing['phone']; ?></div>
						</div>
					</div>

					<table class="table border">
						<thead class="bg-light">
							<tr>
								<th class="text-center">#</th>
								<th>Item</th>
								<th class="text-center">Qty</th>
								<th class="text-center">Unit Cost</th>
								<th class="text-center">Unit Shipping</th>
								<th class="text-center">Total</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td class="text-center">1</td>
								<td class="left strong"><?=$rsi['name']?><?php if($item_size): ?><strong class="pt-color"> (<?=$item_size['name']?>)</strong><?php endif; ?></td>
								<td class="text-center"><?=$cart['item_quantities']?></td>
								<td class="text-center"><?=dollar_sign.(isset($cart['item_price']) ? $cart['item_price'] : ($item_size ? $item_size['price'] : $rsi['selling_price']))?></td>
								<td class="text-center"><?=dollar_sign.(isset($cart['item_delivery']) ? $cart['item_delivery'] : 0)?></td>
								<?php $tttot = (isset($cart['item_price']) ? $cart['item_price'] : ($item_size ? $item_size['price'] : $rsi['selling_price'])) + (isset($cart['item_delivery']) ? $cart['item_delivery'] : 0); ?>
								<td class="text-center"><?=dollar_sign.($tttot*$cart['item_quantities'])?></td>
							</tr>
							<?php
							$toott  += ($tttot*$cart['item_quantities']);
							$tshipp += (isset($cart['item_delivery']) ? $cart['item_delivery']*$cart['item_quantities'] : 0);

							if($cart['item_extra']):
								$i = 1;
							foreach($cart['item_extra'] as $k => $extra):
								$i++;
								$extra = db_unserialize([$rsi['extra'], $extra]);
								$toott += ($extra['price']*$cart['item_quantities']);
							?>
							<tr>
								<td class="text-center"><?php echo $i; ?></td>
								<td class="left strong"><?php echo $extra['name']; ?></td>
								<td class="text-center"><?=$cart['item_quantities']?></td>
								<td class="text-center"><?php echo dollar_sign.$extra['price']; ?></td>
								<td class="text-center">--</td>
								<td class="text-center"><?php echo dollar_sign.($extra['price']*$cart['item_quantities']); ?></td>
							</tr>
							<?php
							endforeach;
							endif;
							?>
						</tbody>
					</table>

					<table class="table border float-right w-25">
						<tbody>
							<tr>
								<td class="left"><strong>Subtotal</strong></td>
								<td class="right"><?php echo dollar_sign.$toott; ?></td>
							</tr>
							<tr>
								<td class="left"><strong>Shipping</strong></td>
								<td class="right"><?php echo dollar_sign.$tshipp; ?></td>
							</tr>
							<tr>
								<td class="left"><strong>Total</strong></td>
								<td class="right"><strong><?php echo dollar_sign.($toott+$tshipp); ?></strong></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		</div>


		<?php endwhile; ?>
		<?php echo fh_pagination("orders",$limit, path."/dashboard.php?pg=orders&") ?>
		<?php else: ?>
			<div class="text-center"><?=$lang['alerts']['no-data']?></div>
		<?php
	endif;?>
	</div>
</div>

<?php elseif(us_level == 4): ?>

	<div class="pt-resaurants pt-restaurantpage">
	<div class="pt-resaurant">
		<?php 
		$sql = $db->query("SELECT * FROM ".prefix."orders WHERE restaurant='{$restaurantId}' ORDER BY id DESC LIMIT {$startpoint} , {$limit}");
		if($sql->num_rows):
			$toott  = 0;	
			$tshipp = 0;

		while($rs = $sql->fetch_assoc()):
			$cart = json_decode($rs['order_cart'], true);
			$billing = json_decode($rs['billing_info'], true);
			$sqli = $db->query("SELECT * FROM ".prefix."items WHERE id = '{$cart['item_id']}'");
			$rsi  = $sqli->fetch_assoc();
			$sqli->close();

			$item_size = isset($cart['item_size']) ? db_unserialize([$rsi['sizes'], $cart['item_size']]) : '';
			$driverSelectionId = 'driver-selection-' . $rs['id'];
		?>
		<div class="pt-cart-body">
			<div class="media">
				<div class="media-left"><div class="pt-thumb"><img src="<?=path?>/<?=$rsi['image']?>" alt="<?=$rsi['name']?>" onerror="this.src='<?=noimage?>'"></div></div>
				<div class="media-body">
					<div class="pt-dtable">
						<div class="pt-vmiddle">
							<div class="pt-title">
								<h3>
									<a href="#">
										<?=$rsi['name']?><?php if($item_size): ?><strong class="pt-color"> (<?=$item_size['name']?>)</strong><?php endif; ?>
									</a>
								</h3>
							</div>
							<div class="pt-extra">
								<strong><i class="fas fa-money-bill-wave"></i> <?=$cart['item_quantities']?> x <a><?=dollar_sign.(isset($cart['item_price']) ? $cart['item_price'] : ($item_size ? $item_size['price'] : $rsi['selling_price']))?></a></strong>
								<strong> - <i class="far fa-clock"></i> <?=fh_ago($rs['created_at'])?></strong>
								<strong> - <i class="fas fa-store"></i> <a href="<?=path?>/restaurants.php?id=<?=$rs['restaurant']?>&t=<?=fh_seoURL(db_get("restaurants", "name", $rs['restaurant']))?>"><?=db_get("restaurants", "name", $rs['restaurant'])?></a></strong>
							</div>
							<div class="pt-extra"><small><?=str_replace("+", " ", $cart['item_note'])?></small></div>
							<div class="pt-extra">
								<?php
								if($cart['item_extra']):
								foreach($cart['item_extra'] as $k => $extra):
									$extra = db_unserialize([$rsi['extra'], $extra]);
								?>
									<span>
										<?=$extra['name']?> <b class="pt-extraprice"><?=dollar_sign.$extra['price']?></b>
									</span>
								<?php
								endforeach;
								endif;
								?>
							</div>
							<div class="pt-options">
								<?php if($rs['status']==2): ?>
								<a class="pt-delivered wdth"><i class="fas fa-check"></i> Delivered</a>
								<?php elseif($rs['status']==1): ?>
								<a class="pt-awaiting wdth bg-v"><i class="fas fa-truck"></i> In the way</a>
								<?php else: ?>
								<a class="pt-awaiting wdth"><i class="fas fa-clock"></i> Awaiting</a>
								<?php endif; ?>
							    <a class="delete-link" href="#" data-id="<?php echo $rs['id']?>"> <i class="fas fa-trash"></i> </a>
								<?php if($rs['status']!=2): ?>
								<a href="#" class="pt-delivered tips" data-id="<?php echo $rs['id'] ?>"><i class="fas fa-check"></i><b>Make it delivered</b></a>
								<?php endif; ?>
								<?php if($rs['status']==0): ?>
								<a href="#" class="pt-intheway tips" data-id="<?php echo $rs['id'] ?>"><i class="fas fa-truck"></i><b>In the way</b></a>
								<?php endif; ?>
								<a href="#" class="pt-addinvoice tips" data-name="<?php echo time()."_".fh_seoURL($rsi['name']); ?>" data-id="<?php echo $rs['id']; ?>"><i class="fas fa-file-invoice-dollar"></i><b>Invoice</b></a>
								<!-- Bouton pour affecter un livreur -->
						    	<a href="#" class="pt-assign-driver tips" data-oid="<?=$rs['id']?>"><i class="fas fa-user"></i><b>Assign Driver</b></a>
                                
								<br><br>
								<!-- Boîte de sélection pour les livreurs -->
    <div id="<?=$driverSelectionId?>" style="display: none;">
        <select class="driver-list">
            <!-- Options des livreurs seront chargées dynamiquement -->
        </select>
        <button class="assign-button" style="display: flex; justify-content: center; align-items: center; width: 100%; height: 100%; background: #ff9f0e; color: #fff; border: 1px solid lightgray; border-radius: 5px;">Assign</button>
    </div>

							</div>

						</div>
					</div>
				</div>
			</div>
			<div class="pt-billing">
				<span><b>Full Name:</b> <?=str_replace("+", " ",$billing['name'])?></span>
				<span><b>Phone:</b> <?=$billing['phone']?></span><br />
				<span><b>Address:</b> <?=str_replace("+", " ",$billing['address'])?>, <?=str_replace("+", " ",$billing['city'])?>  <?=$billing['postal_code']?> - <?=str_replace("+", " ",$billing['state'])?>, <?=$billing['country']?></span>
			</div>
		</div>


		<div class="d-none">
		<div id="invoice_<?php echo $rs['id']; ?>">
			<h1 class="text-center mb-5">Invoice</h1>
			<div class="card">
				<?php
				$sqlr = $db->query("SELECT * FROM ".prefix."restaurants WHERE id = '{$rs['restaurant']}'");
				$rsr  = $sqlr->fetch_assoc();
				$sqlr->close();
				?>
				<div class="card-header">
					Invoice ID: <strong class="text-uppercase"><?php echo md5($rs['id']); ?></strong>
					<span class="float-right">Invoice Date: <strong><?php echo date("d/m/Y H:i"); ?></strong></span>
				</div>
				<div class="card-body">
					<div class="row mb-4">
						<div class="col-sm-6">
							<h6 class="mb-3">From:</h6>
							<div><strong><?php echo $rsr['name']; ?></strong></div>
							<div><?php echo $rsr['address']; ?></div>
							<div><?php echo $rsr['city']." ".$rsr['zipcode']." - ".$rsr['state'].", ".$rsr['country']; ?></div>
							<div>Email: <?php echo $rsr['email']; ?></div>
							<div>Phone: <?php echo $rsr['phone']; ?></div>
						</div>

						<div class="col-sm-6">
							<h6 class="mb-3">To:</h6>
							<div><strong><?php echo str_replace("+", " ",$billing['name']); ?></strong></div>
							<div><?php echo str_replace("+", " ",$billing['address']); ?></div>
							<div><?php echo str_replace("+", " ",$billing['city'])." ".$billing['postal_code']." - ".str_replace("+", " ",$billing['state']).", ".$billing['country']; ?></div>
							<div>Email: <?php echo $billing['email']; ?></div>
							<div>Phone: <?php echo $billing['phone']; ?></div>
						</div>
					</div>

					<table class="table border">
						<thead class="bg-light">
							<tr>
								<th class="text-center">#</th>
								<th>Item</th>
								<th class="text-center">Qty</th>
								<th class="text-center">Unit Cost</th>
								<th class="text-center">Unit Shipping</th>
								<th class="text-center">Total</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td class="text-center">1</td>
								<td class="left strong"><?=$rsi['name']?><?php if($item_size): ?><strong class="pt-color"> (<?=$item_size['name']?>)</strong><?php endif; ?></td>
								<td class="text-center"><?=$cart['item_quantities']?></td>
								<td class="text-center"><?=dollar_sign.(isset($cart['item_price']) ? $cart['item_price'] : ($item_size ? $item_size['price'] : $rsi['selling_price']))?></td>
								<td class="text-center"><?=dollar_sign.(isset($cart['item_delivery']) ? $cart['item_delivery'] : 0)?></td>
								<?php $tttot = (isset($cart['item_price']) ? $cart['item_price'] : ($item_size ? $item_size['price'] : $rsi['selling_price'])) + (isset($cart['item_delivery']) ? $cart['item_delivery'] : 0); ?>
								<td class="text-center"><?=dollar_sign.($tttot*$cart['item_quantities'])?></td>
							</tr>
							<?php
							$toott  += ($tttot*$cart['item_quantities']);
							$tshipp += (isset($cart['item_delivery']) ? $cart['item_delivery']*$cart['item_quantities'] : 0);

							if($cart['item_extra']):
								$i = 1;
							foreach($cart['item_extra'] as $k => $extra):
								$i++;
								$extra = db_unserialize([$rsi['extra'], $extra]);
								$toott += ($extra['price']*$cart['item_quantities']);
							?>
							<tr>
								<td class="text-center"><?php echo $i; ?></td>
								<td class="left strong"><?php echo $extra['name']; ?></td>
								<td class="text-center"><?=$cart['item_quantities']?></td>
								<td class="text-center"><?php echo dollar_sign.$extra['price']; ?></td>
								<td class="text-center">--</td>
								<td class="text-center"><?php echo dollar_sign.($extra['price']*$cart['item_quantities']); ?></td>
							</tr>
							<?php
							endforeach;
							endif;
							?>
						</tbody>
					</table>

					<table class="table border float-right w-25">
						<tbody>
							<tr>
								<td class="left"><strong>Subtotal</strong></td>
								<td class="right"><?php echo dollar_sign.$toott; ?></td>
							</tr>
							<tr>
								<td class="left"><strong>Shipping</strong></td>
								<td class="right"><?php echo dollar_sign.$tshipp; ?></td>
							</tr>
							<tr>
								<td class="left"><strong>Total</strong></td>
								<td class="right"><strong><?php echo dollar_sign.($toott+$tshipp); ?></strong></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
		</div>


		<?php endwhile; ?>
		<?php echo fh_pagination("orders",$limit, path."/restau_dashboard.php?pg=orders&") ?>
		<?php else: ?>
			<div class="text-center"><?=$lang['alerts']['no-data']?></div>
		<?php
	endif;?>
	</div>
</div>


<?php elseif(us_level == 2): ?>

<div class="pt-resaurants pt-restaurantpage">
<div class="pt-resaurant">
	<?php 
	$sql = $db->query("SELECT * FROM ".prefix."orders WHERE driver_id = '$driverId' ORDER BY id DESC LIMIT {$startpoint} , {$limit}");
	if($sql->num_rows):
		$toott  = 0;
		$tshipp = 0;

	while($rs = $sql->fetch_assoc()):
		$cart = json_decode($rs['order_cart'], true);
		$billing = json_decode($rs['billing_info'], true);
		$sqli = $db->query("SELECT * FROM ".prefix."items WHERE id = '{$cart['item_id']}'");
		$rsi  = $sqli->fetch_assoc();
		$sqli->close();

		$item_size = isset($cart['item_size']) ? db_unserialize([$rsi['sizes'], $cart['item_size']]) : '';
	?>
	<div class="pt-cart-body">
		<div class="media">
			<div class="media-left"><div class="pt-thumb"><img src="<?=path?>/<?=$rsi['image']?>" alt="<?=$rsi['name']?>" onerror="this.src='<?=noimage?>'"></div></div>
			<div class="media-body">
				<div class="pt-dtable">
					<div class="pt-vmiddle">
						<div class="pt-title">
							<h3>
								<a href="#">
									<?=$rsi['name']?><?php if($item_size): ?><strong class="pt-color"> (<?=$item_size['name']?>)</strong><?php endif; ?>
								</a>
							</h3>
						</div>
						<div class="pt-extra">
							<strong><i class="fas fa-money-bill-wave"></i> <?=$cart['item_quantities']?> x <a><?=dollar_sign.(isset($cart['item_price']) ? $cart['item_price'] : ($item_size ? $item_size['price'] : $rsi['selling_price']))?></a></strong>
							<strong> - <i class="far fa-clock"></i> <?=fh_ago($rs['created_at'])?></strong>
							<strong> - <i class="fas fa-store"></i> <a href="<?=path?>/restaurants.php?id=<?=$rs['restaurant']?>&t=<?=fh_seoURL(db_get("restaurants", "name", $rs['restaurant']))?>"><?=db_get("restaurants", "name", $rs['restaurant'])?></a></strong>
						</div>
						<div class="pt-extra"><small><?=str_replace("+", " ", $cart['item_note'])?></small></div>
						<div class="pt-extra">
							<?php
							if($cart['item_extra']):
							foreach($cart['item_extra'] as $k => $extra):
								$extra = db_unserialize([$rsi['extra'], $extra]);
							?>
								<span>
									<?=$extra['name']?> <b class="pt-extraprice"><?=dollar_sign.$extra['price']?></b>
								</span>
							<?php
							endforeach;
							endif;
							?>
						</div> 
						<div class="pt-options">
							<?php if($rs['status']==2): ?>
							<a class="pt-delivered wdth"><i class="fas fa-check"></i> Delivered</a>
							<?php elseif($rs['status']==1): ?>
							<a class="pt-awaiting wdth bg-v"><i class="fas fa-truck"></i> In the way</a>
							<?php else: ?>
							<a class="pt-awaiting wdth"><i class="fas fa-clock"></i> Awaiting</a>
							<?php endif; ?>
							<?php if($rs['status']!=2): ?>
							<a href="#" class="pt-delivered tips" data-id="<?php echo $rs['id'] ?>"><i class="fas fa-check"></i><b>Make it delivered</b></a>
							<?php endif; ?>
							<?php if($rs['status']==0): ?>
							<a href="#" class="pt-intheway tips" data-id="<?php echo $rs['id'] ?>"><i class="fas fa-truck"></i><b>In the way</b></a>
							<?php endif; ?>
							<a href="#" class="pt-addinvoice tips" data-name="<?php echo time()."_".fh_seoURL($rsi['name']); ?>" data-id="<?php echo $rs['id']; ?>"><i class="fas fa-file-invoice-dollar"></i><b>Invoice</b></a>

						</div>

					</div>
				</div>
			</div>
		</div>
		<div class="pt-billing">
			<span><b>Full Name:</b> <?=str_replace("+", " ",$billing['name'])?></span>
			<span><b>Phone:</b> <?=$billing['phone']?></span><br />
			<span><b>Address:</b> <?=str_replace("+", " ",$billing['address'])?>, <?=str_replace("+", " ",$billing['city'])?>  <?=$billing['postal_code']?> - <?=str_replace("+", " ",$billing['state'])?>, <?=$billing['country']?></span>
		</div>
	</div>


	<div class="d-none">
	<div id="invoice_<?php echo $rs['id']; ?>">
		<h1 class="text-center mb-5">Invoice</h1>
		<div class="card">
			<?php
			$sqlr = $db->query("SELECT * FROM ".prefix."restaurants WHERE id = '{$rs['restaurant']}'");
			$rsr  = $sqlr->fetch_assoc();
			$sqlr->close();
			?>
			<div class="card-header">
				Invoice ID: <strong class="text-uppercase"><?php echo md5($rs['id']); ?></strong>
				<span class="float-right">Invoice Date: <strong><?php echo date("d/m/Y H:i"); ?></strong></span>
			</div>
			<div class="card-body">
				<div class="row mb-4">
					<div class="col-sm-6">
						<h6 class="mb-3">From:</h6>
						<div><strong><?php echo $rsr['name']; ?></strong></div>
						<div><?php echo $rsr['address']; ?></div>
						<div><?php echo $rsr['city']." ".$rsr['zipcode']." - ".$rsr['state'].", ".$rsr['country']; ?></div>
						<div>Email: <?php echo $rsr['email']; ?></div>
						<div>Phone: <?php echo $rsr['phone']; ?></div>
					</div>

					<div class="col-sm-6">
						<h6 class="mb-3">To:</h6>
						<div><strong><?php echo str_replace("+", " ",$billing['name']); ?></strong></div>
						<div><?php echo str_replace("+", " ",$billing['address']); ?></div>
						<div><?php echo str_replace("+", " ",$billing['city'])." ".$billing['postal_code']." - ".str_replace("+", " ",$billing['state']).", ".$billing['country']; ?></div>
						<div>Email: <?php echo $billing['email']; ?></div>
						<div>Phone: <?php echo $billing['phone']; ?></div>
					</div>
				</div>

				<table class="table border">
					<thead class="bg-light">
						<tr>
							<th class="text-center">#</th>
							<th>Item</th>
							<th class="text-center">Qty</th>
							<th class="text-center">Unit Cost</th>
							<th class="text-center">Unit Shipping</th>
							<th class="text-center">Total</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td class="text-center">1</td>
							<td class="left strong"><?=$rsi['name']?><?php if($item_size): ?><strong class="pt-color"> (<?=$item_size['name']?>)</strong><?php endif; ?></td>
							<td class="text-center"><?=$cart['item_quantities']?></td>
							<td class="text-center"><?=dollar_sign.(isset($cart['item_price']) ? $cart['item_price'] : ($item_size ? $item_size['price'] : $rsi['selling_price']))?></td>
							<td class="text-center"><?=dollar_sign.(isset($cart['item_delivery']) ? $cart['item_delivery'] : 0)?></td>
							<?php $tttot = (isset($cart['item_price']) ? $cart['item_price'] : ($item_size ? $item_size['price'] : $rsi['selling_price'])) + (isset($cart['item_delivery']) ? $cart['item_delivery'] : 0); ?>
							<td class="text-center"><?=dollar_sign.($tttot*$cart['item_quantities'])?></td>
						</tr>
						<?php
						$toott  += ($tttot*$cart['item_quantities']);
						$tshipp += (isset($cart['item_delivery']) ? $cart['item_delivery']*$cart['item_quantities'] : 0);

						if($cart['item_extra']):
							$i = 1;
						foreach($cart['item_extra'] as $k => $extra):
							$i++;
							$extra = db_unserialize([$rsi['extra'], $extra]);
							$toott += ($extra['price']*$cart['item_quantities']);
						?>
						<tr>
							<td class="text-center"><?php echo $i; ?></td>
							<td class="left strong"><?php echo $extra['name']; ?></td>
							<td class="text-center"><?=$cart['item_quantities']?></td>
							<td class="text-center"><?php echo dollar_sign.$extra['price']; ?></td>
							<td class="text-center">--</td>
							<td class="text-center"><?php echo dollar_sign.($extra['price']*$cart['item_quantities']); ?></td>
						</tr>
						<?php
						endforeach;
						endif;
						?>
					</tbody>
				</table>

				<table class="table border float-right w-25">
					<tbody>
						<tr>
							<td class="left"><strong>Subtotal</strong></td>
							<td class="right"><?php echo dollar_sign.$toott; ?></td>
						</tr>
						<tr>
							<td class="left"><strong>Shipping</strong></td>
							<td class="right"><?php echo dollar_sign.$tshipp; ?></td>
						</tr>
						<tr>
							<td class="left"><strong>Total</strong></td>
							<td class="right"><strong><?php echo dollar_sign.($toott+$tshipp); ?></strong></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	</div>


	<?php endwhile; ?>
	<?php echo fh_pagination("orders",$limit, path."/deliverer_dashboard.php?pg=orders&") ?>
	<?php else: ?>
		<div class="text-center"><?=$lang['alerts']['no-data']?></div>
	<?php endif;?>
</div>
</div>

<?php endif; ?>


<script>
	
	document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.delete-link').forEach(link => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            let id = event.target.dataset.id;

            // Demander la confirmation à l'utilisateur
            var confirmation = confirm('Are you sure you want to delete this order?');

            if (confirmation) {
                // Envoyez une requête AJAX pour supprimer l'élément
                fetch('delete-order.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({ id: id })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Affichez la notification de succès
                        showSuccessNotification('Order deleted successfully');
                        
                        // Actualisez la page après une courte attente
                        setTimeout(function() {
                            window.location.reload(true);
                        }, 1000);
                    } else {
                        console.log('Erreur lors de la suppression de la commande:', data.message);
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Erreur lors de la suppression:', error);
                    alert('Une erreur est survenue lors de la suppression.');
                });
            }
        });
    });
});


  // Load and Assign Deliver 

  document.addEventListener('DOMContentLoaded', function() {
    var assignDriverButtons = document.querySelectorAll('.pt-assign-driver');
    assignDriverButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            e.preventDefault();

            // Récupérer l'ID de la commande correspondante
            var orderId = button.getAttribute('data-oid');

            // Construire l'ID de la boîte de sélection du livreur
            var driverSelectionId = 'driver-selection-' + orderId;
            var driverSelection = document.getElementById(driverSelectionId);
            if (driverSelection) {
                // Afficher la boîte de sélection du livreur
                driverSelection.style.display = 'block';

                // Charger les livreurs disponibles via AJAX
                var xhr = new XMLHttpRequest();
                xhr.open('GET', 'load_drivers.php', true);
                xhr.setRequestHeader('Content-Type', 'application/json');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            var drivers = JSON.parse(xhr.responseText);
                            var driverList = driverSelection.querySelector('.driver-list');
                            driverList.innerHTML = ''; // Effacer les anciennes options
                            if (drivers.length > 0) {
                                drivers.forEach(function(driver) {
                                    var option = document.createElement('option');
                                    option.value = driver.id;
                                    option.text = driver.username;
                                    driverList.appendChild(option);
                                });
                            } else {
                                // Aucun chauffeur disponible
                                var option = document.createElement('option');
                                option.text = "No Driver available";
                                driverList.appendChild(option);
                            }
                        } else {
                            console.error('Error loading drivers:', xhr.statusText);
                        }
                    }
                };
                xhr.send();
            }
        });
    });

//////// Gérer l'assignation du livreur lorsque le bouton "Assign" est cliqué
    document.addEventListener('click', function(event) {
        if (event.target.classList.contains('assign-button')) {
            var selectedDriverId = event.target.previousElementSibling.value;
            var orderId = event.target.parentElement.id.split('-')[2]; // Récupérer l'ID de la commande à partir de l'ID de la boîte de sélection

            // Effectuer une requête AJAX pour associer le livreur à la commande
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'assign_driver.php', true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        console.log('Driver assigned successfully:', xhr.responseText);
						showSuccessNotification('Livreur assigné avec succès');
						// Rafraîchir la page après 2 secondes
                        setTimeout(function() {
                        location.reload();
                        }, 1000);
                    } else {
                        console.error('Error assigning driver:', xhr.statusText);
                    }
                }
            };
            var data = JSON.stringify({ driverId: selectedDriverId, orderId: orderId });
            xhr.send(data);
        }
    });
});

/////////////////////////////// NOTIFICATION /////////////////////////////////////

// Fonction pour afficher une notification de succès
function showSuccessNotification(message) {
    // Vérifiez si le navigateur prend en charge les notifications
    if ('Notification' in window) {
        // Vérifiez si les notifications sont autorisées
        if (Notification.permission === 'granted') {
            // Créez une notification
            new Notification('Success', { body: message });
        } else if (Notification.permission !== 'denied') {
            // Demandez la permission à l'utilisateur pour afficher les notifications
            Notification.requestPermission().then(function(permission) {
                if (permission === 'granted') {
                    // Créez une notification si la permission est accordée
                    new Notification('Success', { body: message });
                }
            });
        }
    }
}



//////////////////////////////// Change Driver status /////////////////////////////

var statusSlider = document.getElementById("status-slider");
var statusLabel = document.getElementById("status-label");

statusSlider.addEventListener("input", function() {
    if (this.value == 0) {
        statusLabel.textContent = "Indisponible";
        statusLabel.style.color = "#FF0000"; // Rouge pour indisponible
        // Mettez ici votre code pour mettre à jour le statut dans la base de données
    } else {
        statusLabel.textContent = "Disponible";
        statusLabel.style.color = "#FF9F0E"; // Couleur spécifiée pour disponible
        // Mettez ici votre code pour mettre à jour le statut dans la base de données
    }
});

document.addEventListener('DOMContentLoaded', function() {
    var statusSlider = document.getElementById('status-slider');
    var statusLabel = document.getElementById('status-label');

    // Ajouter un écouteur d'événements pour le changement de valeur du curseur
    statusSlider.addEventListener('input', function() {
        // Mettre à jour la classe du bouton en fonction de la valeur du curseur
        if (statusSlider.value == 1) {
            statusSlider.classList.remove('unavailable');
            statusSlider.classList.add('available');
            statusLabel.textContent = 'Disponible';
        } else {
            statusSlider.classList.remove('available');
            statusSlider.classList.add('unavailable');
            statusLabel.textContent = 'Indisponible';
        }
    });
});

//////////////////////////////// Update Driver status in the Database /////////////////////////////

document.addEventListener('DOMContentLoaded', function() {
    var statusSlider = document.getElementById('status-slider');
    
    statusSlider.addEventListener('change', function() {
        var availability = this.value; // Nouvelle valeur du bouton (0 pour indisponible, 1 pour disponible)
		console.log(availability);
        
        // Envoyer une requête AJAX pour mettre à jour la disponibilité dans la base de données
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'update_availability.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (xhr.status === 200) {
                // Mettre à jour l'affichage ou effectuer d'autres actions si nécessaire
                console.log('Status changed successfully'); // Afficher la réponse du serveur (pour le débogage)
            } else {
                        console.error('Error to change status:', xhr.statusText);
                    }
        };
        xhr.send('availability=' + availability);
    });
});

//////////////// Store Status in the LocalStorage //////////////////////////////

document.addEventListener('DOMContentLoaded', function() {
    // Récupérer le bouton, l'étiquette de statut et le slider
    var slider = document.getElementById('status-slider');
    var statusLabel = document.getElementById('status-label');
    var storedStatus = localStorage.getItem('availability');
    var storedBackgroundColor = localStorage.getItem('background-color');

    // Si une valeur est présente dans le stockage local, appliquez-la au bouton et à la couleur de fond
    if (storedStatus && storedBackgroundColor) {
        slider.value = storedStatus;
        if (storedStatus === '1') {
            statusLabel.textContent = 'Disponible';
        } else {
            statusLabel.textContent = 'Indisponible';
        }
        slider.style.backgroundColor = storedBackgroundColor;
    }

    // Ajouter un écouteur d'événements au bouton pour enregistrer l'état et la couleur de fond dans le stockage local
    slider.addEventListener('input', function() {
        var availability = this.value; // Nouvelle valeur du bouton (0 pour indisponible, 1 pour disponible)
        localStorage.setItem('availability', availability); // Enregistrer l'état dans le stockage local
        if (availability === '1') {
            statusLabel.textContent = 'Disponible';
            this.style.backgroundColor = '#FF9F0E'; // Couleur de fond pour disponible
            localStorage.setItem('background-color', '#FF9F0E'); // Enregistrer la couleur de fond dans le stockage local
        } else {
            statusLabel.textContent = 'Indisponible';
            this.style.backgroundColor = '#F5E3E0'; // Couleur de fond pour indisponible
            localStorage.setItem('background-color', '#F5E3E0'); // Enregistrer la couleur de fond dans le stockage local
        }
    });
});



</script>