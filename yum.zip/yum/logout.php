<?php
// Démarrer la session si ce n'est pas déjà fait
session_start();

// Supprimer le cookie en définissant sa date d'expiration sur une valeur antérieure à la date actuelle
setcookie('addtocart', '', time() - 3600, '/yum');

// Supprimer d'autres cookies si nécessaire
setcookie('PHPSESSID', '', time() - 3600, '/');
setcookie('login', '', time() - 3600, '/');

// Décodez le JSON pour obtenir les détails du cookie
$cookie_details = json_decode($_COOKIE['addtocart'], true);

// Optionnel : Vous pouvez également supprimer les détails du cookie de votre code PHP après les avoir récupérés
unset($_COOKIE['addtocart']);
unset($cookie_details);

// Rediriger l'utilisateur vers la page d'accueil ou une autre page après la déconnexion
header("Location: index.php");
exit;
?>

